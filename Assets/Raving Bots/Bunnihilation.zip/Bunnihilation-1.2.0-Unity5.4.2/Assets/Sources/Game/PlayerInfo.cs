using System;
using System.Collections.Generic;
using RavingBots.MultiInput;
using UnityEngine;

namespace RavingBots.Bunnihilation
{
	[RequireComponent(typeof(PawnController), typeof(PlayerCamera), typeof(AudioMListener))]
	public class PlayerInfo : MonoBehaviour
	{
		Color _color;

		public Color Color {
			get { return _color; }
			set {
				if (_color == value)
					return;

				_color = value;

				HUD.Color = _color;
			}
		}

		int _score;

		public int Score {
			get { return _score; }
			set {
				if (_score == value)
					return;

				_score = value;

				HUD.Score = _score;
			}
		}

		[NonSerialized] public int PlayerNumber;
		public PawnController PawnController { get; private set; }
		public PlayerCamera PlayerCamera { get; private set; }
		public AudioMListener AudioMListener { get; private set; }
		public HUD HUD { get; private set; }

		public List<IDevice> Devices { get { return PawnController.Devices; } }
		public bool HasKeyboard { get { return PawnController.HasKeyboard; } }
		public bool HasMouse { get { return PawnController.HasMouse; } }
		public bool Ready { get { return (HasKeyboard || HasMouse) ? Devices.Count == 2 : Devices.Count == 1; } }

		GameInfo _gameInfo;

		void Awake()
		{
			PawnController = GetComponent<PawnController>();
			PlayerCamera = GetComponent<PlayerCamera>();
			AudioMListener = GetComponent<AudioMListener>();
			HUD = GetComponentInChildren<HUD>();

			_gameInfo = GameInfo.Find();
		}

		public void Play(bool debug)
		{
			if (!debug)
				Debug.Assert(Ready, "Play() called on non-ready player in normal mode.");
			else
				PawnController.UseAnyInput = true;
			PawnController.Setup();
			Respawn();
		}

		public void Respawn()
		{
			var pawn = PawnController.Pawn;
			PawnController.Pawn = null;
			PlayerCamera.Pawn = null;

			if (pawn && pawn.IsAlive)
				pawn.Health = 0f;

			pawn = _gameInfo.Collections.Pawn_Character.TakeInstance();

			_gameInfo.Spawner.Spawn(pawn);

			pawn.Player = this;
			PawnController.Pawn = pawn;
			PlayerCamera.Pawn = pawn;
			PlayerCamera.ResetView();

			var defaultWeapon = _gameInfo.Collections.Weapon_EyeOfDoom.TakeInstance();
			defaultWeapon.gameObject.SetActive(true);

			pawn.Weapon = defaultWeapon;
		}

		public void OnFireDown()
		{
			if (!PawnController.Pawn || !PawnController.Pawn.IsAlive)
				Respawn();
		}

		public void OnKilled(Actor actor)
		{
			if (actor)
			{
				var projectile = actor as Projectile;
				if (!projectile || !projectile.Player)
					return;

				var killer = projectile.Player;
				killer.Score += killer != this ? 1 : -1;

				if (_gameInfo.FragLimit > 0 && killer.Score >= _gameInfo.FragLimit)
					_gameInfo.Finish(killer.PlayerNumber);
			}
			else
				Score--;
		}

		public void Assign(IDevice device, InputCode code)
		{
			Devices.Add(device);

			if (code.IsKeyboard())
				PawnController.HasKeyboard = true;
			else if (code.IsMouse())
				PawnController.HasMouse = true;
		}
	}
}
