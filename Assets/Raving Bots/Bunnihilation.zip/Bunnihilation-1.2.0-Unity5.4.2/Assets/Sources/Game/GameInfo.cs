using System.Linq;
using RavingBots.MultiInput;
using UnityEngine;

namespace RavingBots.Bunnihilation
{
	[RequireComponent(typeof(SplitScreen), typeof(Collections), typeof(AudioManager))]
	public class GameInfo : Singleton<GameInfo>
	{
		public int PlayerCount = 2;
		public int FragLimit = 0;
		public float PowerupCooldown = 10f;

		public Color[] PlayerColors = new Color[0];
		bool _debugMode;

		public PlayerInfo[] Players { get; private set; }

		public Collections Collections { get; private set; }
		public SplitScreen SplitScreen { get; private set; }
		public AudioManager AudioManager { get; private set; }
		public Spawner Spawner { get; private set; }

		float _lastTimeScale = 1f;

		public static bool Paused { get; private set; }

		public bool FarView {
			get { return _cameraMain.gameObject.activeSelf; }
			set {
				if (_cameraMain.gameObject.activeSelf != value)
					_cameraMain.gameObject.SetActive(value);
			}
		}

		Camera _cameraMain;
		MainMenu _mainMenu;
		bool _processInput;

		void Awake()
		{
			Collections = GetComponent<Collections>();
			SplitScreen = GetComponent<SplitScreen>();
			AudioManager = GetComponent<AudioManager>();
			_cameraMain = Camera.main;
			Spawner = Spawner.Find();
			_mainMenu = MainMenu.Find();
			Paused = _mainMenu != null;
			_lastTimeScale = 1;
		}

		void Update()
		{
			if (!_processInput)
				return;

			if (Input.GetKeyDown(KeyCode.F1))
				FarView = !FarView;

			if (Input.GetKeyDown(KeyCode.Escape))
			{
				if (Paused)
					Resume();
				else
					Pause();
			}
		}

		void Start()
		{
			if (_mainMenu)
				return;

			_debugMode = true;
			Debug.LogWarning("Debug mode is active!");
			FindObjectOfType<InputState>().Reset();

			SetupPlayers();
			Play();
		}

		public void Play()
		{
			SetupCameras();
			SetupAudio();

			foreach (var player in Players)
				player.Play(_debugMode);

			_processInput = true;
			Resume();
		}

		public void Finish(int winner)
		{
			if (!_mainMenu)
				return;

			Pause();

			_processInput = false;
			_mainMenu.ShowWinner(winner);
		}

		public void Resume()
		{
			AudioListener.pause = Paused = FarView = false;

			CursorExt.Lock();
			Time.timeScale = _lastTimeScale;
			if (_mainMenu)
				_mainMenu.HidePause();
		}

		public void Pause()
		{
			AudioListener.pause = Paused = FarView = true;

			CursorExt.Release();
			_lastTimeScale = Time.timeScale;
			Time.timeScale = 0f;
			if (_mainMenu)
				_mainMenu.ShowPause();
		}

		public void SetupPlayers()
		{
			Players = new PlayerInfo[PlayerCount];
			for (var i = 0; i < Players.Length; i++)
			{
				var player = Collections.CreatePlayer();
				player.Color = i < PlayerColors.Length ? PlayerColors[i] : Color.black;
				player.PlayerNumber = i + 1;
				Players[i] = player;
			}
		}

		void SetupCameras()
		{
			var viewCameras = Players.Select(p => p.PlayerCamera.Camera).ToArray();
			var hudCameras = Players.Select(p => p.HUD.Camera).ToArray();

			foreach (var c in viewCameras)
			{
				c.transform.position = _cameraMain.transform.position;
				c.transform.rotation = _cameraMain.transform.rotation;
			}

			if (_cameraMain.gameObject.activeSelf)
				_cameraMain.gameObject.SetActive(false);

			SplitScreen.Setup(viewCameras, hudCameras);
		}

		void SetupAudio()
		{
			var listeners = Players.Select(p => p.AudioMListener).ToArray();
			AudioManager.Setup(listeners);
		}
	}
}
