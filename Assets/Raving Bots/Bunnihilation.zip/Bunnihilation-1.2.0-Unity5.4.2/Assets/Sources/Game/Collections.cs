using UnityEngine;

namespace RavingBots.Bunnihilation
{
	public class Collections : MonoBehaviour
	{
		[SerializeField] PlayerInfo PlayerPrefab;
		[SerializeField] Character CharacterPrefab;
		[SerializeField] EyeOfDoom EyeOfDoomPrefab;
		[SerializeField] Bullet BulletPrefab;
		[SerializeField] BlowFX BlowFXPrefab;
		[SerializeField] SpawnFX SpawnFXPrefab;
		[SerializeField] SoundFX SoundFXHighPrefab;
		[SerializeField] SoundFX SoundFXLowPrefab;
		[SerializeField] Medkit MedkitPrefab;

		public int PawnPrecache = 5;
		public ObjectPool<Pawn> Pawn_Character { get; private set; }

		public int WeaponPrecache = 5;
		public ObjectPool<Weapon> Weapon_EyeOfDoom { get; private set; }

		public int ProjectilePrecache = 20;
		public ObjectPool<Projectile> Projectile_Bullet { get; private set; }

		public int FXPrecache = 20;
		public ObjectPool<FX> FX_BlowFX { get; private set; }
		public ObjectPool<FX> FX_SpawnFX { get; private set; }
		public ObjectPool<FX> FX_SoundFX_High { get; private set; }
		public ObjectPool<FX> FX_SoundFX_Low { get; private set; }

		public int PowerupPrecache = 10;
		public ObjectPool<Powerup> Powerup_Medkit { get; private set; }

		void Awake()
		{
			Pawn_Character = new ObjectPool<Pawn>(CharacterPrefab, PawnPrecache);
			Weapon_EyeOfDoom = new ObjectPool<Weapon>(EyeOfDoomPrefab, WeaponPrecache);
			Projectile_Bullet = new ObjectPool<Projectile>(BulletPrefab, ProjectilePrecache);
			FX_BlowFX = new ObjectPool<FX>(BlowFXPrefab, FXPrecache);
			FX_SpawnFX = new ObjectPool<FX>(SpawnFXPrefab, FXPrecache);
			FX_SoundFX_High = new ObjectPool<FX>(SoundFXHighPrefab, FXPrecache);
			FX_SoundFX_Low = new ObjectPool<FX>(SoundFXLowPrefab, FXPrecache);
			Powerup_Medkit = new ObjectPool<Powerup>(MedkitPrefab, PowerupPrecache);
		}

		public PlayerInfo CreatePlayer()
		{
			return Create(PlayerPrefab);
		}

		T Create<T>(T prefab) where T : MonoBehaviour
		{
			return Instantiate(prefab.gameObject).GetComponent<T>();
		}
	}
}
