using System;
using System.Collections.Generic;
using System.Linq;
using RavingBots.MultiInput;
using UnityEngine;

namespace RavingBots.Bunnihilation
{
	[Serializable]
	public class Bindings
	{
		public float SensitivityX;
		public float SensitivityY;
		public List<InputCode> MoveLeft;
		public List<InputCode> MoveRight;
		public List<InputCode> MoveForward;
		public List<InputCode> MoveBackward;
		public List<InputCode> AimLeft;
		public List<InputCode> AimRight;
		public List<InputCode> AimUp;
		public List<InputCode> AimDown;
		public List<InputCode> Crouch;
		public List<InputCode> Jump;
		public List<InputCode> Fire;
		public List<InputCode> ChangeView;

		public Bindings()
		{
			MoveLeft = Create();
			MoveRight = Create();
			MoveForward = Create();
			MoveBackward = Create();
			AimLeft = Create();
			AimRight = Create();
			AimUp = Create();
			AimDown = Create();
			Crouch = Create();
			Jump = Create();
			Fire = Create();
			ChangeView = Create();

			SensitivityX = SensitivityY = 1;
		}

		static List<InputCode> Create(params InputCode[] defaults)
		{
			Debug.Assert(defaults.Length <= 3);

			var list = defaults.ToList();
			while (list.Count < 3)
				list.Add(InputCode.None);

			return list;
		}

		public void Bind(List<InputCode> target, InputCode code, int slot)
		{
			Debug.Assert(slot < target.Count);
			var all = new[]
			{
				MoveLeft,
				MoveRight,
				MoveForward,
				MoveBackward,
				AimLeft,
				AimRight,
				AimUp,
				AimDown,
				Crouch,
				Jump,
				Fire,
				ChangeView,
			};

			foreach (var list in all)
			{
				var idx = list.IndexOf(code);
				if (idx != -1)
					list[idx] = InputCode.None;
			}

			target[slot] = code;
		}

		public static Bindings Load()
		{
			var json = PlayerPrefs.GetString("Bindings", "");
			return string.IsNullOrEmpty(json)
				? CreateDefault()
				: JsonUtility.FromJson<Bindings>(json);
		}

		public static Bindings CreateDefault()
		{
			return new Bindings
			{
				MoveLeft = Create(InputCode.KeyA, InputCode.KeyLeftArrow, InputCode.PadLeftStickLeft),
				MoveRight = Create(InputCode.KeyD, InputCode.KeyRightArrow, InputCode.PadLeftStickRight),
				MoveForward = Create(InputCode.KeyW, InputCode.KeyUpArrow, InputCode.PadLeftStickUp),
				MoveBackward = Create(InputCode.KeyS, InputCode.KeyDownArrow, InputCode.PadLeftStickDown),
				AimLeft = Create(InputCode.MouseXLeft, InputCode.PadRightStickLeft),
				AimRight = Create(InputCode.MouseXRight, InputCode.PadRightStickRight),
				AimUp = Create(InputCode.MouseYUp, InputCode.PadRightStickUp),
				AimDown = Create(InputCode.MouseYDown, InputCode.PadRightStickDown),
				Crouch = Create(InputCode.KeyLeftControl, InputCode.KeyC, InputCode.PadLeftTrigger),
				Jump = Create(InputCode.KeySpace, InputCode.PadA),
				Fire = Create(InputCode.MouseLeft, InputCode.PadRightTrigger),
				ChangeView = Create(InputCode.KeyV, InputCode.PadY)
			};
		}

		public void Save()
		{
			var json = JsonUtility.ToJson(this);
			PlayerPrefs.SetString("Bindings", json);
			PlayerPrefs.Save();
		}

		public static void Reset()
		{
			PlayerPrefs.DeleteKey("Bindings");
			PlayerPrefs.Save();
		}
	}
}
