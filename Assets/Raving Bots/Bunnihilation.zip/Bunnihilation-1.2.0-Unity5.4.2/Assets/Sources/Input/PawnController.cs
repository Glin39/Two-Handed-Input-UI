using System;
using System.Collections.Generic;
using RavingBots.MultiInput;
using UnityEngine;

namespace RavingBots.Bunnihilation
{
	[RequireComponent(typeof(PlayerCamera))]
	public class PawnController : MonoBehaviour
	{
		public Pawn Pawn;
		public readonly List<IDevice> Devices = new List<IDevice>();
		public bool HasKeyboard;
		public bool HasMouse;
		public bool UseAnyInput;

		PlayerCamera _playerCamera;
		PlayerInfo _playerInfo;
		InputState _inputState;
		Bindings _bindings;

		void Awake()
		{
			_playerCamera = GetComponent<PlayerCamera>();
			_playerInfo = GetComponent<PlayerInfo>();
			_inputState = FindObjectOfType<InputState>();
			Devices.Clear();
		}

		public void Setup()
		{
			if (UseAnyInput)
				Devices.AddRange(_inputState.Devices);

			_bindings = Bindings.Load();
		}

		void Update()
		{
			if (!Pawn || GameInfo.Paused)
				return;

			ProcessInput();
		}

		IVirtualAxis FindAxis(IEnumerable<InputCode> codes, out InputCode outCode, Func<IVirtualAxis, bool> predicate)
		{
			// ReSharper disable once LoopCanBeConvertedToQuery
			foreach (var code in codes)
			{
				// ReSharper disable once LoopCanBePartlyConvertedToQuery
				foreach (var device in Devices)
				{
					var axis = device[code];
					if (axis != null && predicate(axis))
					{
						outCode = code;
						return axis;
					}
				}
			}

			outCode = InputCode.None;
			return null;
		}

		bool FindInput(IEnumerable<InputCode> codes, Func<IVirtualAxis, bool> predicate)
		{
			InputCode outCode;
			var axis = FindAxis(codes, out outCode, predicate);
			return axis != null;
		}

		float GetValue(IEnumerable<InputCode> codes)
		{
			InputCode outCode;
			var axis = FindAxis(codes, out outCode, a => a.IsHeld);
			if (axis == null)
				return 0;

			var value = axis.Value;
			return value;
		}

		bool IsUp(IEnumerable<InputCode> codes)
		{
			return FindInput(codes, a => a.IsUp);
		}

		bool IsDown(IEnumerable<InputCode> codes)
		{
			return FindInput(codes, a => a.IsDown);
		}

		bool IsHeld(IEnumerable<InputCode> codes)
		{
			return FindInput(codes, a => a.IsHeld);
		}

		void ProcessInput()
		{
			var moveLeft = GetValue(_bindings.MoveLeft);
			var moveRight = GetValue(_bindings.MoveRight);
			var moveForward = GetValue(_bindings.MoveForward);
			var moveBackward = GetValue(_bindings.MoveBackward);

			var aimLeft = GetValue(_bindings.AimLeft);
			var aimRight = GetValue(_bindings.AimRight);
			var aimUp = GetValue(_bindings.AimUp);
			var aimDown = GetValue(_bindings.AimDown);

			var moveX = moveLeft > 0 ? -moveLeft : moveRight;
			var moveY = moveBackward > 0 ? -moveBackward : moveForward;
			var aimX = aimLeft > 0 ? -aimLeft : aimRight;
			var aimY = aimDown > 0 ? -aimDown : aimUp;

			aimX = aimX * _bindings.SensitivityX;
			aimY = aimY * _bindings.SensitivityY;

			Pawn.InputLook += new Vector2(aimX, aimY) * 100 * Time.deltaTime;
			Pawn.InputMove = new Vector2(moveX, moveY);

			Pawn.InputCrouch = IsHeld(_bindings.Crouch);
			Pawn.InputJump = IsHeld(_bindings.Jump);

			if (IsDown(_bindings.Fire))
			{
				Pawn.InputFire = true;
				if (_playerInfo)
					_playerInfo.OnFireDown();
			}
			else if (IsUp(_bindings.Fire))
				Pawn.InputFire = false;

			if (IsDown(_bindings.ChangeView))
			{
				_playerCamera.ViewMode = _playerCamera.ViewMode == ViewMode.FPS
					? ViewMode.TPS
					: ViewMode.FPS;
			}
		}
	}
}
