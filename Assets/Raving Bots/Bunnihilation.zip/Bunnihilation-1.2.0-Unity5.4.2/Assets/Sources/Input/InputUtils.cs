using System.Linq;
using RavingBots.MultiInput;

namespace RavingBots.Bunnihilation
{
	public class InputUtils
	{
		public static readonly InputCode[] ButtonAxes;

		static InputUtils()
		{
			ButtonAxes = InputStateExt.AllAxes
				.Where(axis => !IsAnalog(axis))
				.ToArray();
		}

		static bool IsAnalog(InputCode axis)
		{
			switch (axis)
			{
				case InputCode.MouseX:
				case InputCode.MouseY:
				case InputCode.MouseWheel:
				case InputCode.MouseXLeft:
				case InputCode.MouseXRight:
				case InputCode.MouseYUp:
				case InputCode.MouseYDown:
				case InputCode.PadLeftStickY:
				case InputCode.PadLeftStickX:
				case InputCode.PadLeftStickDown:
				case InputCode.PadLeftStickUp:
				case InputCode.PadLeftStickLeft:
				case InputCode.PadLeftStickRight:
				case InputCode.PadRightStickY:
				case InputCode.PadRightStickX:
				case InputCode.PadRightStickDown:
				case InputCode.PadRightStickUp:
				case InputCode.PadRightStickLeft:
				case InputCode.PadRightStickRight:
					return true;
				default:
					return false;
			}
		}
	}
}
