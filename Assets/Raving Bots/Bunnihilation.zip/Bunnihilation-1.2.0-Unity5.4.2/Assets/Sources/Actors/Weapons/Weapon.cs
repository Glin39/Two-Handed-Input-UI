using UnityEngine;

namespace RavingBots.Bunnihilation
{
	[RequireComponent(typeof(AudioEmitter))]
	public abstract class Weapon : Actor, IPooledObject<Weapon>
	{
		public ObjectPool<Weapon> Pool { get; set; }
		public bool Queued { get; set; }

		public bool Auto = true;
		public float InitialAmmo = 10f;
		public float Cooldown = 0.1f;

		public float Ammo { get; protected set; }
		public virtual bool CanFire { get { return Pawn && Ammo >= 1f; } }
		
		public bool Firing { get; private set; }
		public AudioEmitter AudioEmitter { get; private set; }
		public readonly RenderColor RenderColor = new RenderColor();

		Pawn _pawn;
		public virtual Pawn Pawn
		{
			get { return _pawn; }
			set
			{
				if (_pawn == value)
					return;

				_pawn = value;

				if (_pawn)
				{
					if (_pawn.Player)
						RenderColor.Color = _pawn.Player.Color;
				}
				else
				{
					Fire(false);
					RenderColor.Reset();
				}
			}
		}

		[SerializeField] protected Sound FireSound;
		[SerializeField] protected Transform Origin;


        float _lastFireTime = -1;

		protected override void Awake()
		{
			base.Awake();

			AudioEmitter = GetComponent<AudioEmitter>();
            RenderColor.Init(this);
        }

		protected override void OnEnable()
		{
			base.OnEnable();

			Debug.Assert(!_pawn);
			Debug.Assert(!Firing);

			Ammo = InitialAmmo;
			_lastFireTime = -1;
        }

		protected virtual void FixedUpdate()
		{
			if (!Firing || _lastFireTime + Cooldown > Time.fixedTime)
				return;

			if (CanFire)
				OnFire();
			else
			{
				OnFail();
				Pawn.InputFire = false;
			}
		}

		public virtual bool Fire(bool state)
		{
			if (Firing == state)
				return false;

			if (state)
			{
				if (!CanFire)
				{
					OnFail();
					return false;
				}

				OnFire();

				if (!Auto)
					return false;
			}

			Firing = state;
			return true;
		}

		protected virtual void OnFire()
		{
			AudioEmitter.Play(FireSound);
			_lastFireTime = Time.fixedTime;
			Ammo--;
		}

		protected virtual void OnFail()
		{ }

		protected override void OnDie()
		{
			base.OnDie();

			Pool.RevokeInstance(this);
		}
	}
}
