using UnityEngine;

namespace RavingBots.Bunnihilation
{
	public class EyeOfDoom : Weapon
	{
		public float RefillRate = 5f;

		GameInfo _gameInfo;

		protected override void Awake()
		{
			base.Awake();
		
			_gameInfo = GameInfo.Find();
        }

		protected override void FixedUpdate()
		{
			base.FixedUpdate();

			if (Firing)
				return;

			Ammo += RefillRate * Time.fixedDeltaTime;

			if (Ammo > InitialAmmo)
				Ammo = InitialAmmo;
		}

		protected override void OnFire()
		{
			base.OnFire();

			var bullet = _gameInfo.Collections.Projectile_Bullet.TakeInstance(Origin.position, true);
			bullet.Weapon = this;
			bullet.transform.rotation = transform.rotation;

			bullet.Launch(bullet.transform.forward, Pawn.Rigidbody.velocity);
		}
	}
}
