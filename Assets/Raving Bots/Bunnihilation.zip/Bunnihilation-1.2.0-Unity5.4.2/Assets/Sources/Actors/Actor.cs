using UnityEngine;

namespace RavingBots.Bunnihilation
{
	public abstract class Actor : MonoBehaviour
	{
		public float InitialHealth = 1f;

		float _health;
		public virtual float Health
		{
			get { return _health; }
			set
			{
				value = Mathf.Clamp(value, 0f, InitialHealth);
				
				if (_health == value)
					return;

				_health = value;

				if (Mathf.Approximately(_health, 0f))
				{
					_health = 0f;
					OnDie();
				}
			}
		}

		public bool IsAlive { get { return Health != 0f; } }

		protected virtual void Awake()
		{ }

		protected virtual void OnEnable()
		{
			Health = InitialHealth;
		}

		public virtual bool ApplyDamage(float damage, Actor actor)
		{
			if (!IsAlive)
				return false;

			if (Health > 0)
				Health -= damage;

			return true;
		}

		protected virtual void OnDie()
		{ }
	}
}
