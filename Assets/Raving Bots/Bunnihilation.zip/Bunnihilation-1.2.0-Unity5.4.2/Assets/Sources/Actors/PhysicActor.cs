using UnityEngine;

namespace RavingBots.Bunnihilation
{
	[RequireComponent(typeof(Rigidbody))]
	public abstract class PhysicActor : Actor
	{
		public Rigidbody Rigidbody { get; private set; }
		public PlanetGravity PlanetGravity { get; private set; }
		public AudioEmitter CollisionEmitter;
		public Sound CollisionSound;
		public float CollisionSoundThreshold = 1f;

		public Quaternion InterpRotation
		{
			get { return Quaternion.Lerp(_lastRotation, transform.rotation, (Time.time - Time.fixedTime) / Time.fixedDeltaTime); }
		}

		Quaternion _lastRotation;

		protected override void Awake()
		{
			base.Awake();

			Rigidbody = GetComponent<Rigidbody>();
			PlanetGravity = PlanetGravity.Find();
		}

		protected override void OnEnable()
		{
			base.OnEnable();

			Rigidbody.velocity = Vector3.zero;
			ResetInterp();
		}

		public void ResetInterp()
		{
			_lastRotation = transform.rotation;
		}

		protected virtual void FixedUpdate()
		{
			if (!PlanetGravity || GameInfo.Paused)
				return;

			if (Rigidbody.useGravity)
				Rigidbody.AddForce(PlanetGravity.GetGravityForce(Rigidbody));

			if (Rigidbody.constraints == RigidbodyConstraints.FreezeRotation)
			{
				_lastRotation = transform.rotation;
				transform.RotateTowardsGravityUp(-PlanetGravity.GetDirection(transform.position));
			}
		}

		public virtual void Push(Vector3 force, Vector3 position)
		{
			Rigidbody.AddForceAtPosition(force, position);
		}

		protected virtual void OnCollisionEnter(Collision collision)
		{
			if (!CollisionEmitter || CollisionEmitter.AudioSource.isPlaying || collision.contacts.Length == 0)
				return;

			var velocity = Vector3.Dot(collision.relativeVelocity, collision.contacts[0].normal);
			if (velocity >= CollisionSoundThreshold)
				CollisionEmitter.Play(CollisionSound);
        }
	}
}
