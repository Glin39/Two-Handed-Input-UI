
namespace RavingBots.Bunnihilation
{
	public class Crate : PhysicActor
	{
		protected override void OnDie()
		{
			base.OnDie();

			gameObject.SetActive(false);
		}
	}
}
