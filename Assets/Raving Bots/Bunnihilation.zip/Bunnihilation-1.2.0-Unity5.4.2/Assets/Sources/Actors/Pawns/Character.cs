using UnityEngine;
using System.Linq;

namespace RavingBots.Bunnihilation
{
	public class Character : Pawn
	{
		public float RagdollDuration = 1f;
		public float RagdollFade = 0.2f;

		public Animator Animator { get; private set; }

		Weapon _weapon;
		public override Weapon Weapon
		{
			get { return _weapon; }
			set
			{
				if (_weapon)
				{
					_weapon.Pawn = null;
					_weapon.Health = 0f;
				}

				_weapon = value;

				if (_weapon)
				{
					_weapon.transform.parent = HeadSlot;
					_weapon.transform.localPosition = Vector3.zero;
					_weapon.transform.localRotation = Quaternion.identity;
					_weapon.Pawn = this;
				}
			}
		}

		float _ragdollTime = -1f;
		public bool Ragdoll
		{
			get { return _ragdollTime >= 0f; }
			set
			{
				if (Ragdoll == value)
					return;

				_ragdollTime = value ? Time.time : -1f;

				SetRagdoll(Ragdoll);
			}
		}

		public override bool IsSupported
		{
			get { return base.IsSupported; }

			protected set
			{
				if (IsSupported && !value)
					FeetEmitter.Stop();

				base.IsSupported = value;
			}
		}

		[SerializeField] protected Transform HeadSlot;
		[SerializeField] protected Transform HeadWrapper;
		[SerializeField] protected float HeadBend = 0.33f;
		[SerializeField] protected AudioEmitter VoiceEmitter;
		[SerializeField] protected AudioEmitter BodyEmitter;
		[SerializeField] protected AudioEmitter FeetEmitter;
		[SerializeField] protected Sound DeathSound;
		[SerializeField] protected Sound HitSound;
		[SerializeField] protected Sound JumpSound;
		[SerializeField] protected Sound WalkSound;
		[SerializeField] protected float WalkSoundMinVolume = 0.1f;
		[SerializeField] protected Sound LandSound;
		[SerializeField] protected float LandSoundThreshold = 1f;

		protected Collider[] Raycasts { get; private set; }

		const string MotionBlendX = "MotionBlendX";
		const string MotionBlendY = "MotionBlendY";
		const string FlyingState = "Flying";

		Limb[] _limbs;
		Torso _torso;
		Vector3 _animatorPosition;

		protected override void Awake()
		{
			base.Awake();

			Animator = GetComponentInChildren<Animator>();
			Raycasts = GetComponentsInChildren<Collider>().Where(c => c.gameObject.layer == PhysicsExt.LayerActorRaycast).ToArray();
			_animatorPosition = Animator.transform.localPosition;
			_limbs = GetComponentsInChildren<Limb>();
			_torso = (Torso)_limbs.FirstOrDefault(l => l is Torso);
        }

		protected override void OnEnable()
		{
			base.OnEnable();

			Animator.SetFloat(MotionBlendX, 0f);
			Animator.SetFloat(MotionBlendY, 0f);
			Animator.SetBool(FlyingState, false);

			Animator.transform.localRotation = Quaternion.identity;
			HeadWrapper.localRotation = Quaternion.identity;
        }

		public override bool ApplyDamage(float damage, Actor actor)
		{
			BodyEmitter.Play(HitSound);

			return base.ApplyDamage(damage, actor);
		}

		void Update()
		{
			if (GameInfo.Paused)
				return;

			if (!IsAlive)
			{
				if (Ragdoll)
					UpdateRagdoll();

				return;
			}

			Animator.transform.rotation = InterpRotation * Quaternion.Euler(0f, InputLook.x, 0f);
			HeadWrapper.localEulerAngles = new Vector3(-InputLook.y * HeadBend, 0f, 0f);
			Animator.SetBool(FlyingState, !IsSupported);
		}

		void UpdateRagdoll()
		{
			var hideTime = _ragdollTime + RagdollDuration;
			if (hideTime <= Time.time)
				OnRevoke();
			else
			{
				var c = RenderColor.Color;
				c.a = Mathf.Clamp01((hideTime - Time.time) / RagdollFade);
				RenderColor.Color = c;
			}
		}

		protected override void FixedUpdate()
		{
			base.FixedUpdate();

			if (!IsAlive || GameInfo.Paused)
				return;

			var baseRotation = WorldBaseRotation;
			var forwardSpeed = Vector3.Dot(Rigidbody.velocity, baseRotation * Vector3.forward);
			var sideSpeed = Vector3.Dot(Rigidbody.velocity, baseRotation * Vector3.right);

			Animator.SetFloat(MotionBlendY, forwardSpeed / Speed);
			Animator.SetFloat(MotionBlendX, sideSpeed / Speed);

			if (!IsSupported)
				return;

			var volume = Mathf.Max(Mathf.Abs(forwardSpeed), Mathf.Abs(sideSpeed)) / Speed;
			if (volume < WalkSoundMinVolume)
			{
				if (FeetEmitter.CurrentSound == WalkSound)
					FeetEmitter.Stop();

				return;
			}

			if (FeetEmitter.CurrentSound != WalkSound)
				FeetEmitter.Play(WalkSound);

			FeetEmitter.AudioSource.volume = volume * WalkSound.Volume;
			FeetEmitter.AudioSource.pitch = volume * WalkSound.Pitch;
        }

		protected override bool OnCrouch(bool state)
		{
			if (base.OnCrouch(state))
			{
				_torso.Crouching = state;
				return true;
			}
			return false;
		}

		protected override bool OnJump(bool state)
		{
			var result = base.OnJump(state);

			if (state && result)
				FeetEmitter.Play(JumpSound);

			return result;
		}

		protected override void OnLand(Vector3 relativeVelocity)
		{
			base.OnLand(relativeVelocity);

			var landVelocity = Vector3.Dot(relativeVelocity, transform.up);
			if (landVelocity >= LandSoundThreshold)
				FeetEmitter.Play(LandSound);
        }

		void SetRagdoll(bool state)
		{
			if (state)
			{
				Animator.transform.parent = null;
            }
			else
			{
                Animator.transform.parent = transform;
				Animator.transform.localPosition = _animatorPosition;
				Animator.transform.localRotation = Quaternion.identity;
			}

			Animator.enabled = !state;

			var velocity = Rigidbody.velocity;
			Rigidbody.detectCollisions = !state;
			Rigidbody.isKinematic = state;
			Rigidbody.useGravity = !state;

			if (state)
				Rigidbody.velocity = Vector3.zero;

			foreach (var limb in _limbs)
			{
				limb.Ragdoll = state;
				if (state)
					limb.Rigidbody.velocity = velocity;
			}

			foreach (var raycast in Raycasts)
				raycast.gameObject.layer = state ? PhysicsExt.LayerRagdoll : PhysicsExt.LayerActorRaycast;

			IgnoreOverlap = state;
		}

		protected override void OnDie()
		{
			base.OnDie();

			FeetEmitter.Stop();
			VoiceEmitter.Play(DeathSound);

			Ragdoll = true;
		}

		protected virtual void OnRevoke()
		{
			_torso.Crouching = false;
			Ragdoll = false;
			Pool.RevokeInstance(this);
		}
	}
}
