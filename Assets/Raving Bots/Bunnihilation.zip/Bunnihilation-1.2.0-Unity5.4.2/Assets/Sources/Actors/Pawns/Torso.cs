using UnityEngine;

namespace RavingBots.Bunnihilation
{
	public class Torso : Limb
	{
		bool _crouching;
		public bool Crouching
		{
			get { return _crouching; }
			set
			{
				if (_crouching == value)
					return;

				_crouching = value;

				SetCrouching(_crouching);
			}
		}

		[SerializeField] protected Mesh CrouchingMesh;
		[SerializeField] protected float CrouchingHeight = 1f;
		[SerializeField] protected float CrouchOffset = 0.25f;

		MeshFilter[] _meshFilters;
		CapsuleCollider _capsuleCollider;
		Mesh _standingMesh;
		float _standingHeight;

		protected override void Awake()
		{
			base.Awake();

			_meshFilters = GetComponentsInChildren<MeshFilter>();
			_capsuleCollider = GetComponent<CapsuleCollider>();
			_standingMesh = _meshFilters[0].mesh;
			_standingHeight = _capsuleCollider.height;
		}

		void SetCrouching(bool state)
		{
			foreach (var mf in _meshFilters)
				mf.mesh = state ? CrouchingMesh : _standingMesh;
			_capsuleCollider.height = state ? CrouchingHeight : _standingHeight;

			transform.localPosition = state ? CrouchOffset * Vector3.up : Vector3.zero;
			transform.parent.localPosition = state ? -2f * CrouchOffset * Vector3.up : Vector3.zero;
		}
	}
}
