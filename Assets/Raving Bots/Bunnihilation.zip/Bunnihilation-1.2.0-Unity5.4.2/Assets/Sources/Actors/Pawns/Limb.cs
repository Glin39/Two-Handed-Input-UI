using UnityEngine;

namespace RavingBots.Bunnihilation
{
	public class Limb : PhysicActor
	{
		public float DamageScale = 1f;

		bool _ragdoll;
		public bool Ragdoll
		{
			get { return _ragdoll; }
			set
			{
				if (_ragdoll == value)
					return;

				_ragdoll = value;

				SetRagdoll(_ragdoll);
			}
		}

		public Pawn Pawn { get; private set; }
		public Joint Joint { get; private set; }

		Vector3 _localPosition;
		Quaternion _localRotation;

		protected override void Awake()
		{
			base.Awake();

			Pawn = GetComponentInParent<Pawn>();
			Joint = GetComponent<Joint>();

			_localPosition = transform.localPosition;
			_localRotation = transform.localRotation;
        }

		public override bool ApplyDamage(float damage, Actor actor)
		{
			return Ragdoll ? base.ApplyDamage(damage, actor) : Pawn.ApplyDamage(DamageScale * damage, actor);
		}

		public override void Push(Vector3 force, Vector3 position)
		{
			if (Ragdoll)
				base.Push(force, position);
			else
				Pawn.Push(force, position);
		}

		void SetRagdoll(bool state)
		{
			if (Joint)
			{
				Joint.autoConfigureConnectedAnchor = false;
				Joint.autoConfigureConnectedAnchor = true;
			}

			Rigidbody.isKinematic = !state;
			Rigidbody.useGravity = state;
			Rigidbody.interpolation = state ? RigidbodyInterpolation.Interpolate : RigidbodyInterpolation.None;

			if (!state)
			{
				transform.localPosition = _localPosition;
				transform.localRotation = _localRotation;
			}
		}
	}
}
