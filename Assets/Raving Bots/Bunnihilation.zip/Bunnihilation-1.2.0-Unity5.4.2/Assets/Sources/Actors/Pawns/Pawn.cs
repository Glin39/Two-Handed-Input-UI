using UnityEngine;
using System.Linq;

namespace RavingBots.Bunnihilation
{
	public abstract class Pawn : PhysicActor, IPooledObject<Pawn>
	{
		public bool Queued { get; set; }
		public ObjectPool<Pawn> Pool { get; set; }

		PlayerInfo _player;
		public virtual PlayerInfo Player
		{
			get { return _player; }
			set
			{
				if (_player == value)
					return;

				_player = value;

				if (!_player)
					RenderColor.Reset();
			}
		}
		public abstract Weapon Weapon { get; set; }

		public float Speed = 2f;
		public float Acceleration = 100f;
		public float Deacceleration = 150f;
		public float ReverseSpeedScale = 0.5f;
		public float CrouchSpeedScale = 0.5f;
		public float FlySpeedScale = 0.1f;
		public float JumpEnergy = 100f;
		public float JumpDuration = 0.2f;
		public float CrouchHeightScale = 0.5f;
		public float MaxSupportAngle = 60f;

		[SerializeField] protected CapsuleCollider OverlapCollider;
		[SerializeField] protected SphereCollider SupportCollider;
		public Transform CameraAnchor;

		public readonly RenderColor RenderColor = new RenderColor();

		public virtual bool IsSupported { get; protected set; }
		const float SupportTolerance = 0.05f;

		Vector2 _inputLook;
		public Vector2 InputLook
		{
			get { return _inputLook; }
			set
			{
				value.y = Mathf.Clamp(value.y, -90f, 90f);
				_inputLook = value;
			}
		}

		Vector2 _inputMove;
		public Vector2 InputMove
		{
			get { return _inputMove; }
			set
			{
				var m = value.magnitude;
				if (m > 1f)
					value /= m;

				_inputMove = value;
			}
		}

		bool _inputCrouch;
		public bool InputCrouch
		{
			get { return _inputCrouch; }
			set
			{
				if (_inputCrouch == value)
					return;

				if (OnCrouch(value))
					_inputCrouch = value;
			}
		}

		bool _inputJump;
		public bool InputJump
		{
			get { return _inputJump; }
			set
			{
				if (_inputJump == value)
					return;

				if (OnJump(value))
					_inputJump = value;
			}
		}

		bool _inputFire;
		public bool InputFire
		{
			get { return _inputFire; }
			set
			{
				if (_inputFire == value)
					return;

				if (OnFire(value))
					_inputFire = value;
			}
		}

		bool _ignoreOverlap;
		public bool IgnoreOverlap
		{
			get { return _ignoreOverlap; }
			set
			{
				if (_ignoreOverlap == value)
					return;

				_ignoreOverlap = value;

				foreach (var c in Overlaps)
					c.gameObject.layer = _ignoreOverlap ? PhysicsExt.LayerIgnoreRaycast : PhysicsExt.LayerActorOverlap;
			}
		}

		protected Quaternion LocalBaseRotation
		{
			get { return Quaternion.FromToRotation(transform.up, _supportNormal) * Quaternion.Euler(0f, InputLook.x, 0f); }
		}

		protected Quaternion WorldBaseRotation
		{
			get { return transform.rotation * LocalBaseRotation; }
		}

		Vector3 _lastSupportPosition;
		Vector3 _supportNormal;

		Vector3 _capsuleStandCenter;
		Vector3 _capsuleCrouchCenter;
		float _capsuleStandHeight;
		float _capsuleCrouchHeight;
		float _jumpEnergy;

		protected Collider[] Overlaps { get; private set; }

		protected override void Awake()
		{
			base.Awake();
		
			_capsuleStandHeight = OverlapCollider.height;
			_capsuleCrouchHeight = _capsuleStandHeight * CrouchHeightScale;
			_capsuleStandCenter = OverlapCollider.center;
			_capsuleCrouchCenter = _capsuleStandCenter - new Vector3(0f, (_capsuleStandHeight - _capsuleCrouchHeight) / 2f, 0f);

			Overlaps = GetComponentsInChildren<Collider>().Where(c => c.gameObject.layer == PhysicsExt.LayerActorOverlap).ToArray();

			RenderColor.Init(this);
        }

		protected override void OnEnable()
		{
			base.OnEnable();

			Player = null;
			Debug.Assert(Weapon == null);

			_inputLook = _inputMove = Vector2.zero;
			_inputCrouch = _inputJump = _inputFire = false;

			ResetSupport();
            _jumpEnergy = 0f;

			SetOverlapCrouching(false);
        }

		void ResetSupport()
		{
			_supportNormal = transform.up;
			_lastSupportPosition = Vector3.zero;
			IsSupported = false;
		}

		protected override void FixedUpdate()
		{
			base.FixedUpdate();

			if (!IsAlive || GameInfo.Paused)
				return;

			if (IsSupported && (transform.position - _lastSupportPosition).sqrMagnitude > SupportTolerance)
			{
				ResetSupport();
				InputCrouch = false;
			}

			ProcessMotion();
        }

		protected virtual void ProcessMotion()
		{
			var speed = Speed;
			if (InputMove.y < 0)
				speed *= ReverseSpeedScale;

			if (!IsSupported)
				speed *= FlySpeedScale;
			else if (InputCrouch)
				speed *= CrouchSpeedScale;

			var input = WorldBaseRotation * new Vector3(InputMove.x, 0, InputMove.y);
			var inputDirection = input.normalized;

			var force = input * Rigidbody.GetPushForce(inputDirection, Acceleration, speed);

			if (IsSupported)
			{
				force += -inputDirection * Rigidbody.GetBrakeForce(-inputDirection, Acceleration, speed);

				var brakeDirection = -(Rigidbody.velocity
					- _supportNormal * Vector3.Dot(Rigidbody.velocity, _supportNormal)
					- inputDirection * Vector3.Dot(Rigidbody.velocity, inputDirection)).normalized;

				force += brakeDirection * Rigidbody.GetBrakeForce(brakeDirection, Deacceleration, 0f);
			}

			if (_jumpEnergy > 0f)
			{
				var e = JumpEnergy * Time.fixedDeltaTime / JumpDuration;
				_jumpEnergy -= e;
				force += e * transform.up;
            }

			if (force != Vector3.zero)
				Rigidbody.AddForce(force);
		}

		protected override void OnCollisionEnter(Collision collision)
		{
			base.OnCollisionEnter(collision);

			ProcessCollision(collision);
		}

		void OnCollisionStay(Collision collision)
		{
			ProcessCollision(collision);
		}

		void ProcessCollision(Collision collision)
		{
			if (!IsAlive || _jumpEnergy > JumpEnergy / 2f)
				return;

			var normal = Vector3.zero;
			foreach (var contact in collision.contacts)
				if (contact.thisCollider == SupportCollider)
					normal += contact.normal;

			if (normal == Vector3.zero)
				return;

			normal.Normalize();

			var angle = Vector3.Angle(transform.up, normal);
			if (angle <= MaxSupportAngle)
			{
				_supportNormal = normal;
				_lastSupportPosition = transform.position;

				if (!IsSupported)
					OnLand(collision.relativeVelocity);

				IsSupported = true;
			}
			else
				ResetSupport();
		}

		protected virtual void OnLand(Vector3 relativeVelocity)
		{ }

		protected virtual bool OnCrouch(bool state)
		{
			if (!IsAlive)
				return false;

			if (state)
			{
				if (!IsSupported)
					return false;
			}
			else
			{
				IgnoreOverlap = true;
				var hit = Physics.SphereCast(new Ray(OverlapCollider.transform.TransformPoint(_capsuleStandCenter), transform.up), 
					OverlapCollider.radius, _capsuleStandHeight / 2, PhysicsExt.MaskOverlap);
				IgnoreOverlap = false;

				if (hit)
					return false;
			}

			SetOverlapCrouching(state);

			return true;
		}

		void SetOverlapCrouching(bool state)
		{
			OverlapCollider.height = state ? _capsuleCrouchHeight : _capsuleStandHeight;
			OverlapCollider.center = state ? _capsuleCrouchCenter : _capsuleStandCenter;
		}

		protected virtual bool OnJump(bool state)
		{
			if (!IsAlive)
				return false;

			if (state)
			{
				if (!InputCrouch && IsSupported && _jumpEnergy <= 0f)
				{
					ResetSupport();
					_jumpEnergy = JumpEnergy;

					return true;
                }

				return false;
			}
			else
			{
				_jumpEnergy = 0f;

				return true;
			}
		}

		protected virtual bool OnFire(bool state)
		{
			if (IsAlive && Weapon)
				return Weapon.Fire(state);

			return false;
		}

		public override bool ApplyDamage(float damage, Actor actor)
		{
			if (base.ApplyDamage(damage, actor))
			{
				if (!IsAlive && Player)
					Player.OnKilled(actor);

				return true;
			}
			return false;
		}

		protected override void OnDie()
		{
			base.OnDie();

			Weapon = null;
		}

		void OnDrawGizmos()
		{
			Gizmos.color = Color.red;
			Gizmos.DrawLine(transform.position, transform.position + _supportNormal);

			Gizmos.color = Color.blue;
			Gizmos.DrawLine(transform.position, transform.position + WorldBaseRotation * new Vector3(InputMove.x, 0, InputMove.y));
		}
	}
}
