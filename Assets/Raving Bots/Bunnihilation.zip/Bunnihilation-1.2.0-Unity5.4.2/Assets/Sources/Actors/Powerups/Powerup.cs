using UnityEngine;

namespace RavingBots.Bunnihilation
{
	public abstract class Powerup : Actor, IPooledObject<Powerup>
	{
		public ObjectPool<Powerup> Pool { get; set; }
		public bool Queued { get; set; }

		public SpawnPoint SpawnPoint { get; set; }

		void OnTriggerEnter(Collider other)
		{
			if (other.gameObject.layer == PhysicsExt.LayerActorOverlap)
				if (OnTake(other.GetComponentInParent<Pawn>()))
					Health = 0f;
        }

		protected abstract bool OnTake(Pawn pawn);

		protected override void OnDie()
		{
			base.OnDie();

			Pool.RevokeInstance(this);

			if (SpawnPoint)
			{
				SpawnPoint.OnPowerupTaken(this);
				SpawnPoint = null;
			}
        }
	}
}
