using UnityEngine;

namespace RavingBots.Bunnihilation
{
	public class Medkit : Powerup
	{
		public float Heal = 0.25f;
		[SerializeField] protected Sound TakeSound;
		[SerializeField] protected Transform Animated;
		[SerializeField] protected float RotationSpeed = 1f;
		[SerializeField] protected float FloatSpeed = 1f;
		[SerializeField] protected float FloatRange = 1f;

		Vector3 _localPosition;
		Quaternion _localRotation;
		GameInfo _gameInfo;

		protected override void Awake()
		{
			base.Awake();

			_localPosition = Animated.localPosition;
			_localRotation = Animated.localRotation;
			_gameInfo = GameInfo.Find();
		}

		protected override void OnEnable()
		{
			base.OnEnable();

			Animated.localPosition = _localPosition;
			Animated.localRotation = _localRotation;
		}

		protected override bool OnTake(Pawn pawn)
		{
			if (pawn.Health >= pawn.InitialHealth)
				return false;

			pawn.Health += Heal;

			var soundFX = (SoundFX)_gameInfo.Collections.FX_SoundFX_High.TakeInstance(transform.position, true);
			soundFX.Sound = TakeSound;
			soundFX.Play();

			return true;
		}

		void Update()
		{
			Animated.localPosition = _localPosition + new Vector3(0f, FloatRange * (1f + Mathf.Sin(Time.time * FloatSpeed)), 0f);
			Animated.localRotation *= Quaternion.Euler(0f, RotationSpeed * Time.deltaTime, 0f);
        }
	}
}
