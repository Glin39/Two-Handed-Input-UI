using UnityEngine;

namespace RavingBots.Bunnihilation
{
	public class Bullet : Projectile
	{
		public float PushForce = 100;

		[SerializeField] protected float TerminalTrailTime = 0.2f;
		[SerializeField] protected Sound HitSound;
		[SerializeField] protected GameObject Ball;

		TrailRenderer _trailRenderer;
		GameInfo _gameInfo;
		Vector3 _lastVelocity;
		float _detonateTime;
		float _trailTime;

		protected override void Awake()
		{
			base.Awake();

			_trailRenderer = GetComponent<TrailRenderer>();
			_trailTime = _trailRenderer.time;

			_gameInfo = GameInfo.Find();
        }

		protected override void OnEnable()
		{
			base.OnEnable();

			_lastVelocity = Vector3.zero;
			_detonateTime = -1f;

			if (!Ball.activeSelf)
				Ball.SetActive(true);
			Rigidbody.isKinematic = false;
			Rigidbody.useGravity = true;

			_trailRenderer.time = _trailTime;
			_trailRenderer.Clear();
		}

		protected override void FixedUpdate()
		{
			base.FixedUpdate();

			_lastVelocity = Rigidbody.velocity;
		}

		void Update()
		{
			if (_detonateTime < 0)
				return;

			if (_detonateTime + _trailRenderer.time <= Time.time)
				Dispose();
		}

		void Detonate(PhysicActor actor, Vector3 normal)
		{
			_detonateTime = Time.time;

			Ball.SetActive(false);
			Rigidbody.velocity = Vector3.zero;
			Rigidbody.isKinematic = true;
			Rigidbody.useGravity = false;
			
			_trailRenderer.time = TerminalTrailTime;

			var blow = _gameInfo.Collections.FX_BlowFX.TakeInstance(transform.position, true);
			blow.transform.up = normal;
			blow.Play();

			var soundFX = (SoundFX)_gameInfo.Collections.FX_SoundFX_High.TakeInstance(transform.position, true);
			soundFX.Sound = HitSound;
			soundFX.Play();

			if (actor)
			{
				actor.ApplyDamage(Damage, this);

				var scale = Vector3.Dot(-normal, _lastVelocity.normalized);
				if (scale > 0f)
					actor.Push(-PushForce * scale * normal, transform.position);
			}
		}

		protected override void OnHit(PhysicActor actor, Vector3 normal)
		{
			Detonate(actor, normal);

			base.OnHit(actor, normal);
		}

		protected override void OnDie()
		{
			base.OnDie();
			
			if (_detonateTime < 0)
				Detonate(null, -Rigidbody.velocity.normalized);
		}
	}
}
