using UnityEngine;

namespace RavingBots.Bunnihilation
{
	public class Projectile : PhysicActor, IPooledObject<Projectile>
	{
		public ObjectPool<Projectile> Pool { get; set; }
		public bool Queued { get; set; }

		public float LaunchVelocity = 10;
		public float Damage = 1f;
		public float TimeToLive = 10;

		Weapon _weapon;
		public virtual Weapon Weapon
		{
			get { return _weapon; }
			set
			{
				if (_weapon == value)
					return;

				_weapon = value;

				if (_weapon && _weapon.Pawn && _weapon.Pawn.Player)
				{
					Player = _weapon.Pawn.Player;
					RenderColor.Color = Player.Color;
				}
				else
				{
					Player = null;
					RenderColor.Reset();
                }
			}
		}

		public PlayerInfo Player { get; private set; }

		public readonly RenderColor RenderColor = new RenderColor();

		Collider _collider;
		float _launchTime;
		
		protected override void Awake()
		{
			base.Awake();

			_collider = GetComponentInChildren<Collider>();
			RenderColor.Init(this);
		}

		protected override void OnEnable()
		{
			base.OnEnable();

			Weapon = null;
			_launchTime = -1;

			transform.rotation = Quaternion.identity;
			transform.localScale = Vector3.one;
			_collider.isTrigger = true;
		}

		public virtual void Launch(Vector3 direction, Vector3 ownerVelocity)
		{
			Rigidbody.AddForce(direction * LaunchVelocity + ownerVelocity, ForceMode.VelocityChange);
			_launchTime = Time.time;
        }

		void Update()
		{
			if (!IsAlive || _launchTime < 0 || TimeToLive < 0)
				return;

			if (_launchTime + TimeToLive <= Time.time)
				Health = 0f;
		}

		void OnTriggerEnter(Collider other)
		{
			if (!IsAlive)
				return;

			switch (other.gameObject.layer)
			{
				case PhysicsExt.LayerVolume:
					return;
				case PhysicsExt.LayerDefault:
					OnHit(null, -transform.forward);
					break;
				default:
					var actor = other.GetComponentInParent<PhysicActor>();
					if (!actor || actor.GetComponentInParent<Pawn>() != Weapon.Pawn)
						OnHit(actor, -transform.forward);
					break;
			}
		}

		void OnTriggerExit(Collider other)
		{
			if (!IsAlive)
				return;

			if (other.gameObject.layer == PhysicsExt.LayerActorRaycast)
			{
				var pawn = other.GetComponentInParent<Pawn>();
				if (pawn == Weapon.Pawn)
					_collider.isTrigger = false;
			}
		}

		protected override void OnCollisionEnter(Collision collision)
		{
			base.OnCollisionEnter(collision);

			if (!IsAlive)
				return;

			var normal = collision.contacts.Length > 0 ? collision.contacts[0].normal : -transform.forward;

			if (collision.collider.gameObject.layer == PhysicsExt.LayerDefault)
				OnHit(null, normal);
			else
			{
				var actor = collision.collider.GetComponentInParent<PhysicActor>();
				OnHit(actor, normal);
			}
		}

		protected virtual void OnHit(PhysicActor actor, Vector3 normal)
		{
			Health = 0f;
		}

		public virtual void Dispose()
		{
			Pool.RevokeInstance(this);
		}
	}
}
