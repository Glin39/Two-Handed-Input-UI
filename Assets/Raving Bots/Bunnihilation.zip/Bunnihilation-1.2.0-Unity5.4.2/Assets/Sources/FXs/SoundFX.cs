using UnityEngine;

namespace RavingBots.Bunnihilation
{
	[RequireComponent(typeof(AudioEmitter))]
	public class SoundFX : FX
	{
		public AudioEmitter AudioEmitter { get; private set; }
		public Sound Sound;

		protected override void Awake()
		{
			base.Awake();

			AudioEmitter = GetComponent<AudioEmitter>();
		}

		public override void Play()
		{
			base.Play();

			AudioEmitter.Play(Sound);
			TimeToLive = AudioEmitter.AudioSource.clip.length;
		}
	}
}
