using UnityEngine;

namespace RavingBots.Bunnihilation
{
	public class SpawnFX : FX
	{
		public AnimationCurve RingEasing;

		public float LiftDistance = 0.5f;
		public float InnerRadius = 0.25f;
		public float OuterRadius = 0.5f;

		ProceduralTorus[] _rings;
		Vector3[] _positions;

		protected override void Awake()
		{
			base.Awake();

			_rings = GetComponentsInChildren<ProceduralTorus>();
			_positions = new Vector3[_rings.Length];

			for (var i = 0; i < _rings.Length; i++)
				_positions[i] = _rings[i].transform.localPosition;
		}

		protected override void ProgressUpdate()
		{
			base.ProgressUpdate();

			var p = RingEasing.Evaluate(Progress);

			for (var i = 0; i < _rings.Length; i++)
			{
				var r = _rings[i];
				r.transform.localPosition = _positions[i] + p * LiftDistance * Vector3.up;
				r.InnerRadius = (1f - p) * InnerRadius;
				r.OuterRadius = OuterRadius;
				r.Build(false);
			}
		}
	}
}
