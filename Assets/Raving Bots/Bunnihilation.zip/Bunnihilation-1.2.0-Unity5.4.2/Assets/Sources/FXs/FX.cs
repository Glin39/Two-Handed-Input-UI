using UnityEngine;

namespace RavingBots.Bunnihilation
{
	public abstract class FX : MonoBehaviour, IPooledObject<FX>
	{
		public ObjectPool<FX> Pool { get; set; }
		public bool Queued { get; set; }

		public float TimeToLive = 1f;

		float _progress;
		public float Progress
		{
			get { return _progress; }
			private set
			{
				value = Mathf.Clamp01(value);

				if (_progress == value)
					return;

				_progress = value;

				ProgressUpdate();
			}
		}

		float _startTime = -1f;

		protected virtual void Awake()
		{ }

		protected virtual void OnEnable()
		{
			Progress = 0f;
			_startTime = -1f;
		}

		public virtual void Play()
		{
			_startTime = Time.time;
		}

		protected virtual void ProgressUpdate()
		{ }

		protected virtual void Update()
		{
			if (_startTime < 0)
				return;

			if (_startTime + TimeToLive <= Time.time)
				Dispose();
			else
				Progress = Mathf.Clamp01((Time.time - _startTime) / TimeToLive);
		}

		public virtual void Dispose()
		{
			Pool.RevokeInstance(this);
		}
	}
}
