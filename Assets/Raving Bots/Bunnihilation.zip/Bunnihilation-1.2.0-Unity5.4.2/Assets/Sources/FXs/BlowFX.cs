using UnityEngine;

namespace RavingBots.Bunnihilation
{
	[RequireComponent(typeof(ProceduralTorus))]
	public class BlowFX : FX
	{
		public AnimationCurve RingEasing;

		public float InnerRadius = 0.25f;
		public float OuterRadius = 0.5f;

		[Range(0f, 1f)] public float RingLifetime = 1f;
		public int ParticleCount = 10;
		[Range(0f, 1f)] public float RandomizeLifetime = 0f;
		[Range(0f, 1f)] public float RandomizeSpeed = 0f;

		ProceduralTorus _proceduralTorus;
		ParticleSystem _particleSystem;
		ParticleSystem.Particle[] _particles;

		protected override void Awake()
		{
			base.Awake();

			_proceduralTorus = GetComponent<ProceduralTorus>();
			_particleSystem = GetComponentInChildren<ParticleSystem>();
			_particles = new ParticleSystem.Particle[ParticleCount];

			_particleSystem.Stop();
		}

		public override void Play()
		{
			base.Play();

			_particleSystem.Emit(ParticleCount);

			if (_particles.Length != ParticleCount)
				_particles = new ParticleSystem.Particle[ParticleCount];

			_particleSystem.GetParticles(_particles);

			for (var i = 0; i < _particles.Length; i++)
			{
				if (RandomizeLifetime > 0f)
					_particles[i].startLifetime *= (1f - Random.value * RandomizeLifetime);

				if (RandomizeSpeed > 0f)
					_particles[i].velocity *= (1f - Random.value * RandomizeSpeed);
			}

			_particleSystem.SetParticles(_particles, _particles.Length);
			_particleSystem.Play();
		}

		protected override void ProgressUpdate()
		{
			base.ProgressUpdate();

			if (RingLifetime <= 0)
				return;

			var p = Mathf.Clamp01(Progress / RingLifetime);
			var e = RingEasing.Evaluate(p);

			_proceduralTorus.InnerRadius = (1f - e) * InnerRadius;
			_proceduralTorus.OuterRadius = e * OuterRadius;
			_proceduralTorus.Build(false);
		}

		public override void Dispose()
		{
			base.Dispose();

			_particleSystem.Clear();
			_particleSystem.Stop();
        }
	}
}
