﻿using UnityEngine;

namespace RavingBots.Bunnihilation
{
	public static class PhysicsExt
	{
		public const int LayerDefault = 0;
		public const int LayerIgnoreRaycast = 2;
		public const int LayerActorOverlap = 8;
		public const int LayerActorRaycast = 9;
		public const int LayerProjectile = 10;
		public const int LayerRagdoll = 11;
		public const int LayerItem = 12;
		public const int LayerVolume = 13;

		public const int MaskOverlap = 1 << LayerDefault | 1 << LayerActorOverlap;

		public static float GetPushForce(this Rigidbody rigidbody, Vector3 direction, float maxForce, float maxVelocity)
		{
			if (direction == Vector3.zero)
				return 0f;

			Debug.Assert(Mathf.Approximately(direction.magnitude, 1f));

			var velocity = Vector3.Dot(rigidbody.velocity, direction);
			if (velocity > maxVelocity)
				return 0f;

			var dt = Time.fixedDeltaTime;

			var deltaVelocity = dt * maxForce / rigidbody.mass;
			if (deltaVelocity > maxVelocity - velocity)
				deltaVelocity = maxVelocity - velocity;

			return rigidbody.mass * deltaVelocity / dt;
		}

		public static float GetBrakeForce(this Rigidbody rigidbody, Vector3 direction, float maxForce, float minVelocity)
		{
			if (direction == Vector3.zero)
				return 0f;

			Debug.Assert(Mathf.Approximately(direction.magnitude, 1f));

			var velocity = -Vector3.Dot(rigidbody.velocity, direction);
			if (velocity <= minVelocity)
				return 0f;

			var dt = Time.fixedDeltaTime;

			var deltaVelocity = dt * maxForce / rigidbody.mass;
			if (deltaVelocity > velocity - minVelocity)
				deltaVelocity = velocity - minVelocity;

			return rigidbody.mass * deltaVelocity / dt;
		}

		public static void RotateTowardsGravityUp(this Transform t, Vector3 up)
		{
			t.rotation = Quaternion.LookRotation(Quaternion.FromToRotation(t.up, up) * t.forward, up);
		}
	}
}
