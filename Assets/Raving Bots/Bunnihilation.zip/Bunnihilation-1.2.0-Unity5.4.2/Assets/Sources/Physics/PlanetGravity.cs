using UnityEngine;

namespace RavingBots.Bunnihilation
{
	public class PlanetGravity : Singleton<PlanetGravity>
	{
		public float Scale = 1f;

		float _g;
		Vector3 _defaultGravity;
		
		void OnEnable()
		{
			_g = Physics.gravity.magnitude;

			_defaultGravity = Physics.gravity;
			Physics.gravity = Vector3.zero;
		}

		public Vector3 GetDirection(Vector3 position)
		{
			return (transform.position - position).normalized;
		}

		public Vector3 GetGravityForce(Rigidbody rb)
		{
			Debug.Assert(rb.useGravity);

			return Scale * _g * rb.mass * GetDirection(rb.transform.position);
		}

		void OnDisable()
		{
			Physics.gravity = _defaultGravity;
		}
	}
}
