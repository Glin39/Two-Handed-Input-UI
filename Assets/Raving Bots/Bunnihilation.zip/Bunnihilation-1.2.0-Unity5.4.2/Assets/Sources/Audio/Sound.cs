using UnityEngine;

namespace RavingBots.Bunnihilation
{
	[System.Serializable]
	public class Sound
	{
		public float Volume = 1f;
		public float Pitch = 1f;
		public bool Looped;

		public AudioClip Clip
		{
			get
			{
				if (Variants == null || Variants.Length == 0)
					return null;

				return Variants[Variants.Length == 1 ? 0 : Random.Range(0, Variants.Length)];
			}
		}

		public AudioClip[] Variants;
	}
}
