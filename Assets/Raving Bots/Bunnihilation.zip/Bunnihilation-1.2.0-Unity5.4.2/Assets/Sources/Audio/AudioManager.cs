using UnityEngine;

namespace RavingBots.Bunnihilation
{
	[RequireComponent(typeof(AudioListener), typeof(AudioSource))]
	public class AudioManager : Singleton<AudioManager>
	{
		public bool PlayMusic = true;
		public AudioMListener[] AudioMListeners { get; private set; }
		public AudioSource AudioSource { get; private set; }

		void Awake()
		{
			AudioSource = GetComponent<AudioSource>();
		}

		void Start()
		{
			if (PlayMusic)
				AudioSource.Play();
		}

		public void Setup(AudioMListener[] listeners)
		{
			Debug.Assert(listeners != null && listeners.Length > 0);

			AudioMListeners = listeners;
		}

		public AudioMListener FindListener(AudioEmitter emitter)
		{
			if (AudioMListeners == null || AudioMListeners.Length == 0)
				return null;

			var result = AudioMListeners[0];

			if (AudioMListeners.Length > 1)
			{
				var dist = float.MaxValue;
				foreach (var listener in AudioMListeners)
				{
					var d = (emitter.transform.position - listener.transform.position).sqrMagnitude;
					if (dist > d)
					{
						dist = d;
						result = listener;
					}
				}
			}

			return result;
		}
	}
}
