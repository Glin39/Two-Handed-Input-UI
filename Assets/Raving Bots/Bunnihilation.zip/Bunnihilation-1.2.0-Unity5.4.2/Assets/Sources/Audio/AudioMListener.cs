using UnityEngine;

namespace RavingBots.Bunnihilation
{
	public class AudioMListener : MonoBehaviour
	{
		AudioManager _audioManager;

		void Awake()
		{
			_audioManager = AudioManager.Find();
		}

		public void Transform(AudioEmitter emitter)
		{
			var localPosition = transform.InverseTransformPoint(emitter.transform.position);
			emitter.AudioSource.transform.position = _audioManager.transform.TransformPoint(localPosition);
		}
	}
}
