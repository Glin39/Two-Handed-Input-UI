using UnityEngine;

namespace RavingBots.Bunnihilation
{
	public class AudioEmitter : MonoBehaviour
	{
		public AudioSource AudioSource { get; private set; }
		public AudioMListener AudioMListener { get; private set; }
		public Sound CurrentSound { get; private set; }

		AudioManager _audioManager;

		void Awake()
		{
			_audioManager = AudioManager.Find();
			Debug.Assert(!GetComponent<AudioSource>());
			AudioSource = GetComponentInChildren<AudioSource>();
		}

		public void Play(Sound sound)
		{
			AudioSource.Stop();
			AudioSource.clip = sound.Clip;
			AudioSource.volume = sound.Volume;
			AudioSource.pitch = sound.Pitch;
			AudioSource.loop = sound.Looped;

			SetupListener();

			if (AudioSource.clip != null)
				AudioSource.Play();
			else
				Debug.LogWarning("No audio clip");

			CurrentSound = sound;
        }

		public void Stop()
		{
			AudioSource.Stop();
			AudioSource.clip = null;
			AudioSource.volume = AudioSource.pitch = 1f;
			AudioSource.loop = false;
			CurrentSound = null;
			AudioMListener = null;

			AudioSource.transform.position = transform.position;
		}

		public void SetupListener()
		{
			AudioMListener = _audioManager.FindListener(this);
			UpdateTransform();
		}

		void UpdateTransform()
		{
			if (!AudioMListener)
			{
				Debug.Assert(!AudioSource.isPlaying);
				return;
			}

			AudioMListener.Transform(this);
		}

		void LateUpdate()
		{
			UpdateTransform();

			if (!AudioSource.isPlaying)
				Stop();
		}

		void OnDisable()
		{
			Stop();
		}
	}
}
