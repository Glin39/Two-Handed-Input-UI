using UnityEngine;

namespace RavingBots.Bunnihilation
{
	[RequireComponent(typeof(MeshFilter), typeof(MeshRenderer))]
	public class ProceduralTorus : MonoBehaviour
	{
		public int Segments = 24;
		public int Sides = 18;
		public float InnerRadius = 0.3f;
		public float OuterRadius = 1f;

		protected MeshFilter MeshFilter { get; private set; }

		const float Pi2 = Mathf.PI * 2f;

		void Awake()
		{
			MeshFilter = GetComponent<MeshFilter>();
		}

		[ContextMenu("Clear")]
		public void Clear()
		{
			MeshFilter.mesh.Clear();
		}

		[ContextMenu("Build")]
		public void Build(bool optimize = true)
		{
			Clear();

			if (Segments < 3 || Sides < 3 || InnerRadius <= 0f || OuterRadius <= 0f)
				return;

			var mesh = MeshFilter.mesh;
			var vertices = new Vector3[(Segments + 1) * (Sides + 1)];
			
			for (var seg = 0; seg <= Segments; seg++)
			{
				var currSeg = seg == Segments ? 0 : seg;

				var t1 = (float)currSeg / Segments * Pi2;
				var r1 = new Vector3(Mathf.Cos(t1) * OuterRadius, 0f, Mathf.Sin(t1) * OuterRadius);

				for (var side = 0; side <= Sides; side++)
				{
					var currSide = side == Sides ? 0 : side;

					var t2 = (float)currSide / Sides * Pi2;
					var r2 = Quaternion.AngleAxis(-t1 * Mathf.Rad2Deg, Vector3.up) * new Vector3(Mathf.Sin(t2) * InnerRadius, Mathf.Cos(t2) * InnerRadius);

					vertices[side + seg * (Sides + 1)] = r1 + r2;
				}
			}
			
			var normales = new Vector3[vertices.Length];
			for (var seg = 0; seg <= Segments; seg++)
			{
				var currSeg = seg == Segments ? 0 : seg;

				var t1 = (float)currSeg / Segments * Pi2;
				var r1 = new Vector3(Mathf.Cos(t1) * OuterRadius, 0f, Mathf.Sin(t1) * OuterRadius);

				for (var side = 0; side <= Sides; side++)
					normales[side + seg*(Sides + 1)] = (vertices[side + seg*(Sides + 1)] - r1).normalized;
			}
			
			var uvs = new Vector2[vertices.Length];
			for (var seg = 0; seg <= Segments; seg++)
				for (var side = 0; side <= Sides; side++)
					uvs[side + seg * (Sides + 1)] = new Vector2((float)seg / Segments, (float)side / Sides);
			
			var nbFaces = vertices.Length;
			var nbTriangles = nbFaces * 2;
			var nbIndexes = nbTriangles * 3;
			var triangles = new int[nbIndexes];

			var i = 0;
			for (var seg = 0; seg <= Segments; seg++)
			{
				for (var side = 0; side <= Sides - 1; side++)
				{
					var current = side + seg * (Sides + 1);
					var next = side + (seg < (Segments) ? (seg + 1) * (Sides + 1) : 0);

					if (i >= triangles.Length - 6)
						continue;

					triangles[i++] = current;
					triangles[i++] = next;
					triangles[i++] = next + 1;

					triangles[i++] = current;
					triangles[i++] = next + 1;
					triangles[i++] = current + 1;
				}
			}

			mesh.vertices = vertices;
			mesh.normals = normales;
			mesh.uv = uvs;
			mesh.triangles = triangles;

			mesh.RecalculateBounds();

			if (optimize)
				mesh.Optimize();
		}
	}
}
