using UnityEngine;

namespace RavingBots.Bunnihilation
{
	public class SplitScreen : MonoBehaviour
	{
		[SerializeField] float BorderWidth = 8;
		[SerializeField] bool PreferHorizontal;

		public Camera[] ViewCameras { get; private set; }
		public Camera[] HUDCameras { get; private set; }

		int _columns;
		int _windowWidth;
		int _windowHeight;

		public void Setup(Camera[] viewCameras, Camera[] hudCameras)
		{
			Debug.Assert(viewCameras != null && hudCameras != null && viewCameras.Length == hudCameras.Length);
			
			ViewCameras = viewCameras;
			HUDCameras = hudCameras;

			if (ViewCameras.Length > 1)
				_columns = PreferHorizontal ? 1 : 2;
			else
				_columns = 1;

			CalculateViewports();
        }

		void CalculateViewports()
		{
			if (ViewCameras == null)
				return;

			_windowWidth = Screen.width;
			_windowHeight = Screen.height;

			var hBorder = BorderWidth / _windowWidth;
			var vBorder = BorderWidth / _windowHeight;

			var rows = Mathf.CeilToInt(ViewCameras.Length / (float)_columns);

			var screenWidth = _columns > 1 ? (1f - (_columns - 1) * hBorder) / _columns : 1f;
			var screenHeight = rows > 1 ? (1f - (rows - 1) * vBorder) / rows : 1f;

			for (var i = 0; i < ViewCameras.Length; i++)
			{
				var x = i % _columns;
				var y = rows - 1 - i / _columns;

				var left = x * (hBorder + screenWidth);
				var top = y * (vBorder + screenHeight);

				ViewCameras[i].rect = HUDCameras[i].rect = new Rect(left, top, screenWidth, screenHeight);
			}
		}

		void LateUpdate()
		{
			if (_windowWidth != Screen.width || _windowHeight != Screen.height)
				CalculateViewports();
		}
	}
}
