using UnityEngine;

namespace RavingBots.Bunnihilation
{
	public enum ViewMode { FPS, TPS }

	[RequireComponent(typeof(Camera))]
	public class PlayerCamera : MonoBehaviour
	{
		public ViewMode ViewMode;
        public Pawn Pawn;
		public Vector3 Offset = new Vector3(0f, 1.5f, -4f);
		public float FadeOffset = 3f;
		public float BackDamp = 0.1f;

		public Camera Camera { get; private set; }

		float _backVelocity;
		float _distance;
		float _lastFade;

		void Awake()
		{
			Camera = GetComponent<Camera>();
			ResetView();
        }

		public void ResetView()
		{
			_backVelocity = 0f;
			_distance = Offset.magnitude;
        }

		void LateUpdate()
		{
			if (!Pawn || !Pawn.gameObject.activeSelf || GameInfo.Paused)
				return;

			var rotY = Quaternion.Euler(0f, Pawn.InputLook.x, 0f);
			var rotX = Quaternion.Euler(-Pawn.InputLook.y, 0f, 0f);

			if (ViewMode == ViewMode.TPS || !Pawn.IsAlive)
				CalculateTPS(rotX, rotY);
			else
				CalculateFPS(rotX, rotY);
		}

		void CalculateFPS(Quaternion rotX, Quaternion rotY)
		{
			transform.position = Pawn.CameraAnchor.position;
			transform.rotation = Pawn.InterpRotation * rotY * rotX;
		}

		void CalculateTPS(Quaternion rotX, Quaternion rotY)
		{
			var zScale = 1f - Mathf.Abs(Pawn.InputLook.y) / 90f;
			var offset = Pawn.InterpRotation * rotY * new Vector3(Offset.x, Offset.y, zScale * Offset.z);
			var length = offset.magnitude;

			if (Mathf.Approximately(length, 0f))
				return;

			var direction = offset / length;

			var ignoreOverlap = !Pawn.IgnoreOverlap;
			if (ignoreOverlap)
				Pawn.IgnoreOverlap = true;

			RaycastHit hit;
			if (Physics.Raycast(Pawn.CameraAnchor.position, direction, out hit, length, PhysicsExt.MaskOverlap))
				length = hit.distance;

			if (ignoreOverlap)
				Pawn.IgnoreOverlap = false;

			if (_distance > length)
			{
				_distance = length;
				_backVelocity = 0f;
			}
			else
				_distance = Mathf.SmoothDamp(_distance, length, ref _backVelocity, BackDamp);

			transform.position = Pawn.CameraAnchor.position + _distance * direction;
			transform.rotation = Pawn.InterpRotation * rotY * rotX;
		}

		void OnPreRender()
		{
			if (!Pawn)
				return;

			_lastFade = Pawn.RenderColor.Color.a;

			PawnFade(ViewMode == ViewMode.TPS || !Pawn.IsAlive ? _lastFade * Mathf.Clamp01(_distance / FadeOffset) : 0f);
		}

		void OnPostRender()
		{
			if (!Pawn)
				return;

			PawnFade(_lastFade);
		}

		void PawnFade(float a)
		{
			var c = Pawn.RenderColor.Color;
			c.a = a;
			Pawn.RenderColor.Color = c;

			if (!Pawn.Weapon)
				return;

			c = Pawn.Weapon.RenderColor.Color;
			c.a = a;
			Pawn.Weapon.RenderColor.Color = c;
		}
	}
}
