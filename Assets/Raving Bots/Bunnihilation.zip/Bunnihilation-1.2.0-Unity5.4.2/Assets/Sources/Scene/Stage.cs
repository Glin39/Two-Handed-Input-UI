using UnityEngine;

namespace RavingBots.Bunnihilation
{
	[RequireComponent(typeof(Collider))]
	public class Stage : MonoBehaviour
	{
		public Collider Bounds { get; private set; }

		void Awake()
		{
			Bounds = GetComponent<Collider>();
		}

		void OnTriggerExit(Collider other)
		{
			var actor = other.GetComponentInParent<Actor>();
			if (actor && actor.IsAlive)
				actor.ApplyDamage(float.MaxValue, null);
		}
    }
}
