using UnityEngine;

namespace RavingBots.Bunnihilation
{
	public enum SpawnType { Pawn, Powerup }

	[ExecuteInEditMode]
	public class SpawnPoint : MonoBehaviour
	{
		public SpawnType SpawnType;
		public Sound SpawnSound;

		public Spawner Spawner { get; private set; }
		public bool Occupied { get; private set; }
		public float PowerupTakeTime { get; private set; }

		GameInfo _gameInfo;

		void Awake()
		{
			Spawner = GetComponentInParent<Spawner>();
			PowerupTakeTime = -1f;
			_gameInfo = GameInfo.Find();
		}

#if UNITY_EDITOR
		void Update()
		{
			if (Application.isPlaying)
				return;

			var planetGravity = PlanetGravity.Find();
			if (planetGravity)
				transform.RotateTowardsGravityUp(-planetGravity.GetDirection(transform.position));
			else
				transform.RotateTowardsGravityUp(-Physics.gravity);
		}

		[ContextMenu("Snap To Ground")]
		void SnapToGround()
		{
			RaycastHit hit;
			if (Physics.Raycast(transform.position, -transform.up, out hit, float.MaxValue, PhysicsExt.MaskOverlap))
				transform.position = hit.point;
		}
#endif

		public void OnSpawn(Actor actor)
		{
			if (SpawnType == SpawnType.Powerup)
			{
				Occupied = true;
				((Powerup)actor).SpawnPoint = this;
			}

			actor.transform.rotation = transform.rotation;

			var physicActor = actor as PhysicActor;
			if (physicActor)
				physicActor.ResetInterp();

			var spawnFX = _gameInfo.Collections.FX_SpawnFX.TakeInstance(transform.position, true);
			spawnFX.transform.rotation = transform.rotation;
			spawnFX.Play();

			var soundFX = (SoundFX)_gameInfo.Collections.FX_SoundFX_High.TakeInstance(transform.position, true);
			soundFX.Sound = SpawnSound;
			soundFX.Play();
		}

		public void OnPowerupTaken(Powerup powerup)
		{
			Occupied = false;
			PowerupTakeTime = Time.time;
		}

		void OnDrawGizmos()
		{
			var matrix = Gizmos.matrix;
			Gizmos.matrix = transform.localToWorldMatrix;

			if (SpawnType == SpawnType.Pawn)
			{
				Gizmos.color = Color.blue;
				Gizmos.DrawSphere(Vector3.zero, 0.05f);
				Gizmos.DrawWireCube(Vector3.up, new Vector3(1f, 2f, 1f));
				Gizmos.DrawLine(Vector3.zero, Vector3.forward);
			}
			else
			{
				Gizmos.color = Color.black;
				Gizmos.DrawSphere(Vector3.zero, 0.05f);
				Gizmos.DrawWireCube(Vector3.up / 2f, new Vector3(1f, 1f, 1f));
			}

			Gizmos.matrix = matrix;
		}
	}
}
