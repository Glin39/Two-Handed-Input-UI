using UnityEngine;
using System.Linq;

namespace RavingBots.Bunnihilation
{
	public class Spawner : Singleton<Spawner>
	{
		public SpawnPoint[] SpawnPoints { get; private set; }

		GameInfo _gameInfo;

		void Awake()
		{
			SpawnPoints = GetComponentsInChildren<SpawnPoint>();

			_gameInfo = GameInfo.Find();
		}

		public void Spawn(Pawn pawn)
		{
			var otherPawns = _gameInfo.Players
				.Select(p => p.PawnController.Pawn)
				.Where(p => p != null && p.IsAlive)
				.Select(p => p.transform.position).ToArray();

			var spawn = otherPawns.Length > 0 ? FindFarthest(otherPawns, SpawnType.Pawn) : FindRandom(SpawnType.Pawn);

			pawn.transform.position = spawn.transform.position;
			pawn.gameObject.SetActive(true);

			spawn.OnSpawn(pawn);
		}

		void Update()
		{
			if (GameInfo.Paused)
				return;

			var spawnPoints = GetSpawnPoints(SpawnType.Powerup);

			foreach (var spawn in spawnPoints)
			{
				if (spawn.Occupied)
					continue;

				if (spawn.PowerupTakeTime < 0 || spawn.PowerupTakeTime + _gameInfo.PowerupCooldown <= Time.time)
				{
					var medkit = _gameInfo.Collections.Powerup_Medkit.TakeInstance(spawn.transform.position, true);

					spawn.OnSpawn(medkit);
				}
			}
		}

		public SpawnPoint[] GetSpawnPoints(SpawnType spawnType)
		{
			return SpawnPoints.Where(s => s.SpawnType == spawnType).ToArray();
		}

		public SpawnPoint FindFarthest(Vector3[] positions, SpawnType spawnType)
		{
			var spawnPoints = GetSpawnPoints(spawnType);
			if (spawnPoints.Length == 0)
				return null;

			var result = spawnPoints[0];
			var distance = 0f;

			foreach (var spawn in spawnPoints)
			{
				var d = positions.Select(p => (p - spawn.transform.position).sqrMagnitude).Sum();
				if (distance < d)
				{
					distance = d;
					result = spawn;
				}
			}

			return result;
		}

		public SpawnPoint FindRandom(SpawnType spawnType)
		{
			var spawnPoints = GetSpawnPoints(spawnType);
			if (spawnPoints.Length == 0)
				return null;

			return spawnPoints[Random.Range(0, spawnPoints.Length)];
		}
	}
}
