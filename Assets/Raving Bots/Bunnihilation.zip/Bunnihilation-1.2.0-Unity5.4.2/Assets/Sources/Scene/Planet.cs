using UnityEngine;

namespace RavingBots.Bunnihilation
{
	public class Planet : MonoBehaviour
	{
		public Sound CollisionSound;
		public float CollisionSoundThreshold = 0.1f;

		GameInfo _gameInfo;

		void Awake()
		{
			_gameInfo = GameInfo.Find();
        }

		void OnCollisionEnter(Collision collision)
		{
			if (collision.contacts.Length == 0)
				return;

			var velocity = Vector3.Dot(collision.relativeVelocity, collision.contacts[0].normal);
			if (velocity >= CollisionSoundThreshold)
			{
				var soundFX = (SoundFX)_gameInfo.Collections.FX_SoundFX_Low.TakeInstance(transform.position, true);
				soundFX.Sound = CollisionSound;
				soundFX.Play();
			}
		}
	}
}
