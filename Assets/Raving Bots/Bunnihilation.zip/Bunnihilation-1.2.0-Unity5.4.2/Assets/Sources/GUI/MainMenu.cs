using System.Linq;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;
#if UNITY_EDITOR
using UnityEditor;
#endif

// ReSharper disable UnassignedField.Global

namespace RavingBots.Bunnihilation
{
	public class MainMenu : Singleton<MainMenu>
	{
		enum Panel
		{
			Main,
			Devices,
			Options,
			Winner,
			Paused
		}

		public Dropdown PlayerCount;
		public Slider FragLimit;
		public Text FragLimitLabel;
		public GameObject MainPanel;
		public GameObject WinnerPanel;
		public GameObject PausedPanel;
		public Text WinnerLabel;
		public GameObject Logos;
		public GameObject TitleBar;
		public Text Title;

		GameInfo _gameInfo;
#pragma warning disable 649
		AssignDevices _assignDevices;
		BindButtons _bindButtons;
#pragma warning restore 649

		void Awake()
		{
			_assignDevices = GetComponent<AssignDevices>();
			_bindButtons = GetComponent<BindButtons>();

			ShowMain();

			_gameInfo = GameInfo.Find();
			var maxPlayers = _gameInfo.PlayerColors.Length;

			PlayerCount.ClearOptions();
			PlayerCount.AddOptions(
				Enumerable.Range(1, maxPlayers)
					.Select(x => string.Format("{0} player{1}", x, x > 1 ? "s" : ""))
					.ToList());
			PlayerCount.value = Mathf.Min(1, maxPlayers);
			PlayerCount.RefreshShownValue();
		}

		void OnEnable()
		{
			FragLimit.onValueChanged.AddListener(UpdateFragLimit);
			UpdateFragLimit(FragLimit.value);
		}

		void OnDisable()
		{
			FragLimit.onValueChanged.RemoveAllListeners();
		}

		public void ShowOptions()
		{
			_bindButtons.Setup();
			SetActivePanel(Panel.Options);
		}

		public void ShowMain()
		{
			SetActivePanel(Panel.Main);
		}

		public void ShowDevices()
		{
			_gameInfo.FragLimit = (int)FragLimit.value;
			_gameInfo.PlayerCount = PlayerCount.value + 1;
			_gameInfo.SetupPlayers();

			_assignDevices.Setup();
			SetActivePanel(Panel.Devices);
		}

		public void ShowWinner(int winner) {
			WinnerLabel.text = string.Format("Player {0} wins!", winner);
			SetActivePanel(Panel.Winner);
		}

		public void ShowPause()
		{
			SetActivePanel(Panel.Paused);
		}

		public void HidePause()
		{
			gameObject.SetActive(false);
		}

		public void ReloadGame()
		{
			AudioListener.pause = false;
			SceneManager.LoadScene(0);
		}

		public void Quit()
		{
#if UNITY_EDITOR
			EditorApplication.isPlaying = false;
#else
			Application.Quit();
#endif
		}

		void UpdateFragLimit(float value)
		{
			var intValue = (int)value;
			FragLimitLabel.text = intValue == 0 ? "none" : intValue.ToString();
		}

		void SetActivePanel(Panel panel)
		{
			gameObject.SetActive(true);

			switch (panel)
			{
				case Panel.Options:
					Title.text = "CONFIGURE CONTROLS";
					TitleBar.SetActive(true);
					break;
				case Panel.Devices:
					Title.text = "ASSIGN DEVICES";
					TitleBar.SetActive(true);
					break;
				default:
					TitleBar.SetActive(false);
					break;
			}

			_bindButtons.enabled = panel == Panel.Options;
			_assignDevices.enabled = panel == Panel.Devices;
			MainPanel.SetActive(panel == Panel.Main);
			Logos.SetActive(panel == Panel.Main);
			WinnerPanel.SetActive(panel == Panel.Winner);
			PausedPanel.SetActive(panel == Panel.Paused);
		}
	}
}
