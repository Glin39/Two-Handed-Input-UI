using System;
using System.Collections.Generic;
using System.Linq;
using RavingBots.MultiInput;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;

// ReSharper disable UnassignedField.Global

namespace RavingBots.Bunnihilation
{
	public class BindButtons : MonoBehaviour
	{
		public GameObject Panel;
		public Text Instructions;

		Bindings _bindings;
		ButtonRow.Types? _listening;
		EventSystem _eventSystem;
		InputState _inputState;
		readonly Dictionary<ButtonRow.Types, ButtonRow> _buttons = new Dictionary<ButtonRow.Types, ButtonRow>();
		int _listeningSlot;

		void Awake()
		{
			_eventSystem = FindObjectOfType<EventSystem>();
			_inputState = FindObjectOfType<InputState>();
		}

		void OnDisable()
		{
			Panel.SetActive(false);
			StopListening();
		}

		public void Setup()
		{
			Instructions.gameObject.SetActive(false);
			Panel.SetActive(true);

			_listening = null;
			StopListening();
			_bindings = Bindings.Load();

			foreach (var row in Panel.GetComponentsInChildren<SensitivityRow>())
			{
				row.Reset();

				switch (row.Type)
				{
					case SensitivityRow.Types.Horizontal:
						row.Slider.value = _bindings.SensitivityX;
						break;
					case SensitivityRow.Types.Vertical:
						row.Slider.value = _bindings.SensitivityY;
						break;
				}

				row.Attach(SensitivityChanged);
			}

			_buttons.Clear();

			foreach (var row in Panel.GetComponentsInChildren<ButtonRow>())
			{
				row.Reset();
				_buttons[row.Type] = row;
				UpdateButtonRow(row.Type);
				row.Attach(ButtonClicked);
			}
		}

		void ButtonClicked(ButtonRow.Types type, int slot)
		{
			var row = _buttons[type];
			row.SlotLabels[slot].text = "<press new>";
			StartListening(type, slot);
		}

		void UpdateButtonRow(ButtonRow.Types type)
		{
			var row = _buttons[type];
			row.Slot1Label.text = GetLabel(type, 0);
			row.Slot2Label.text = GetLabel(type, 1);
			row.Slot3Label.text = GetLabel(type, 2);
		}

		void UpdateAllButtonRows()
		{
			foreach (var type in Enum.GetValues(typeof(ButtonRow.Types)).Cast<ButtonRow.Types>())
				UpdateButtonRow(type);
		}

		string GetLabel(ButtonRow.Types type, int slot)
		{
			var list = GetBindings(type);
			var code = list[slot];

			switch (code)
			{
				default:
					return "{unknown}";
				case InputCode.None:
					return "<unassigned>";
				case InputCode.Key0:
					return "0";
				case InputCode.Key1:
					return "1";
				case InputCode.Key2:
					return "2";
				case InputCode.Key3:
					return "3";
				case InputCode.Key4:
					return "4";
				case InputCode.Key5:
					return "5";
				case InputCode.Key6:
					return "6";
				case InputCode.Key7:
					return "7";
				case InputCode.Key8:
					return "8";
				case InputCode.Key9:
					return "9";
				case InputCode.KeyA:
					return "A";
				case InputCode.KeyB:
					return "B";
				case InputCode.KeyC:
					return "C";
				case InputCode.KeyD:
					return "D";
				case InputCode.KeyE:
					return "E";
				case InputCode.KeyF:
					return "F";
				case InputCode.KeyG:
					return "G";
				case InputCode.KeyH:
					return "H";
				case InputCode.KeyI:
					return "I";
				case InputCode.KeyJ:
					return "J";
				case InputCode.KeyK:
					return "K";
				case InputCode.KeyL:
					return "L";
				case InputCode.KeyM:
					return "M";
				case InputCode.KeyN:
					return "N";
				case InputCode.KeyO:
					return "O";
				case InputCode.KeyP:
					return "P";
				case InputCode.KeyQ:
					return "Q";
				case InputCode.KeyR:
					return "R";
				case InputCode.KeyS:
					return "S";
				case InputCode.KeyT:
					return "T";
				case InputCode.KeyU:
					return "U";
				case InputCode.KeyV:
					return "V";
				case InputCode.KeyW:
					return "W";
				case InputCode.KeyX:
					return "X";
				case InputCode.KeyY:
					return "Y";
				case InputCode.KeyZ:
					return "Z";
				case InputCode.KeySemicolon:
					return ";";
				case InputCode.KeySlash:
					return "/";
				case InputCode.KeyAccent:
					return "`";
				case InputCode.KeyLeftBracket:
					return "[";
				case InputCode.KeyBackslash:
					return "\\";
				case InputCode.KeyRightBracket:
					return "]";
				case InputCode.KeyQuote:
					return "'";
				case InputCode.KeyOem8:
					return "KeyOem8";
				case InputCode.KeyOem102:
					return "KeyOem102";
				case InputCode.KeyBackspace:
					return "Backspace";
				case InputCode.KeyTab:
					return "Tab";
				case InputCode.KeyClear:
					return "Clear";
				case InputCode.KeyEnter:
					return "Enter";
				case InputCode.KeyEscape:
					return "Escape";
				case InputCode.KeySpace:
					return "Space";
				case InputCode.KeyPlus:
					return "=";
				case InputCode.KeyComma:
					return ",";
				case InputCode.KeyMinus:
					return "-";
				case InputCode.KeyPeriod:
					return ".";
				case InputCode.KeyNum0:
					return "Numpad 0";
				case InputCode.KeyNum1:
					return "Numpad 1";
				case InputCode.KeyNum2:
					return "Numpad 2";
				case InputCode.KeyNum3:
					return "Numpad 3";
				case InputCode.KeyNum4:
					return "Numpad 4";
				case InputCode.KeyNum5:
					return "Numpad 5";
				case InputCode.KeyNum6:
					return "Numpad 6";
				case InputCode.KeyNum7:
					return "Numpad 7";
				case InputCode.KeyNum8:
					return "Numpad 8";
				case InputCode.KeyNum9:
					return "Numpad 9";
				case InputCode.KeyNumDecimal:
					return "Numpad .";
				case InputCode.KeyNumDivide:
					return "Numpad /";
				case InputCode.KeyNumMultiply:
					return "Numpad *";
				case InputCode.KeyNumMinus:
					return "Numpad -";
				case InputCode.KeyNumPlus:
					return "Numpad +";
				case InputCode.KeyNumEnter:
					return "Numpad Enter";
				case InputCode.KeyUpArrow:
					return "Up Arrow";
				case InputCode.KeyDownArrow:
					return "Down Arrow";
				case InputCode.KeyRightArrow:
					return "Right Arrow";
				case InputCode.KeyLeftArrow:
					return "Left Arrow";
				case InputCode.KeyInsert:
					return "Insert";
				case InputCode.KeyDelete:
					return "Delete";
				case InputCode.KeyHome:
					return "Home";
				case InputCode.KeyEnd:
					return "End";
				case InputCode.KeyPageUp:
					return "Page Up";
				case InputCode.KeyPageDown:
					return "Page Down";
				case InputCode.KeyF1:
					return "F1";
				case InputCode.KeyF2:
					return "F2";
				case InputCode.KeyF3:
					return "F3";
				case InputCode.KeyF4:
					return "F4";
				case InputCode.KeyF5:
					return "F5";
				case InputCode.KeyF6:
					return "F6";
				case InputCode.KeyF7:
					return "F7";
				case InputCode.KeyF8:
					return "F8";
				case InputCode.KeyF9:
					return "F9";
				case InputCode.KeyF10:
					return "F10";
				case InputCode.KeyF11:
					return "F11";
				case InputCode.KeyF12:
					return "F12";
				case InputCode.KeyF13:
					return "F13";
				case InputCode.KeyF14:
					return "F14";
				case InputCode.KeyF15:
					return "F15";
				case InputCode.KeyF16:
					return "F16";
				case InputCode.KeyF17:
					return "F17";
				case InputCode.KeyF18:
					return "F18";
				case InputCode.KeyF19:
					return "F19";
				case InputCode.KeyF20:
					return "F20";
				case InputCode.KeyF21:
					return "F21";
				case InputCode.KeyF22:
					return "F22";
				case InputCode.KeyF23:
					return "F23";
				case InputCode.KeyF24:
					return "F24";
				case InputCode.KeyRightShift:
					return "Right Shift";
				case InputCode.KeyLeftShift:
					return "Left Shift";
				case InputCode.KeyRightAlt:
					return "Right Alt";
				case InputCode.KeyLeftAlt:
					return "Left Alt";
				case InputCode.KeyRightControl:
					return "Right Control";
				case InputCode.KeyLeftControl:
					return "Left Control";
				case InputCode.KeyRightCommand:
					return "Right Command";
				case InputCode.KeyLeftCommand:
					return "Left Command";
				case InputCode.KeyApps:
					return "Menu";
				case InputCode.KeyPrintScreen:
					return "Print Screen";
				case InputCode.KeyPause:
					return "Pause";
				case InputCode.KeyCapsLock:
					return "CapsLock";
				case InputCode.KeyNumLock:
					return "NumLock";
				case InputCode.KeyScrollLock:
					return "ScrollLock";
				case InputCode.MouseLeft:
					return "Left Mouse Button";
				case InputCode.MouseRight:
					return "Right Mouse Button";
				case InputCode.MouseMiddle:
					return "Middle Mouse Button";
				case InputCode.MouseFourth:
					return "Fourth Mouse Button";
				case InputCode.MouseFifth:
					return "Fifth Mouse Button";
				case InputCode.MouseSixth:
					return "Sixth Mouse Button";
				case InputCode.MouseSeventh:
					return "Seventh Mouse Button";
				case InputCode.MouseXLeft:
					return "Mouse Left";
				case InputCode.MouseXRight:
					return "Mouse Right";
				case InputCode.MouseYUp:
					return "Mouse Up";
				case InputCode.MouseYDown:
					return "Mouse Down";
				case InputCode.MouseWheelUp:
					return "Mouse Wheel Up";
				case InputCode.MouseWheelDown:
					return "Mouse Wheel Down";
				case InputCode.MouseX:
					return "{MouseX}";
				case InputCode.MouseY:
					return "{MouseY}";
				case InputCode.MouseWheel:
					return "{MouseWheel}";
				case InputCode.PadLeftStickUp:
					return "Left Stick Up";
				case InputCode.PadLeftStickDown:
					return "Left Stick Down";
				case InputCode.PadLeftStickLeft:
					return "Left Stick Left";
				case InputCode.PadLeftStickRight:
					return "Left Stick Right";
				case InputCode.PadLeftStick:
					return "{PadLeftStick}";
				case InputCode.PadLeftStickX:
					return "{PadLeftStickX}";
				case InputCode.PadLeftStickY:
					return "{PadLeftStickY}";
				case InputCode.PadRightStickUp:
					return "Right Stick Up";
				case InputCode.PadRightStickDown:
					return "Right Stick Down";
				case InputCode.PadRightStickLeft:
					return "Right Stick Left";
				case InputCode.PadRightStickRight:
					return "Right Stick Right";
				case InputCode.PadRightStick:
					return "{PadRightStick}";
				case InputCode.PadRightStickX:
					return "{PadRightStickX}";
				case InputCode.PadRightStickY:
					return "{PadRightStickY}";
				case InputCode.PadDPadUp:
					return "DPad Up";
				case InputCode.PadDPadDown:
					return "DPad Down";
				case InputCode.PadDPadLeft:
					return "DPad Left";
				case InputCode.PadDPadRight:
					return "DPad Right";
				case InputCode.PadDPadX:
					return "{PadDPadX}";
				case InputCode.PadDPadY:
					return "{PadDPadY}";
				case InputCode.PadA:
					return "Pad A";
				case InputCode.PadB:
					return "Pad B";
				case InputCode.PadX:
					return "Pad X";
				case InputCode.PadY:
					return "Pad Y";
				case InputCode.PadLeftTrigger:
					return "Left Trigger";
				case InputCode.PadRightTrigger:
					return "Right Trigger";
				case InputCode.PadLeftBumper:
					return "Left Bumper";
				case InputCode.PadRightBumper:
					return "Right Bumper";
				case InputCode.PadBack:
					return "Pad Back";
				case InputCode.PadStart:
					return "Pad Start";
			}
		}

		List<InputCode> GetBindings(ButtonRow.Types type)
		{
			switch (type)
			{
				case ButtonRow.Types.MoveLeft:
					return _bindings.MoveLeft;
				case ButtonRow.Types.MoveRight:
					return _bindings.MoveRight;
				case ButtonRow.Types.MoveForward:
					return _bindings.MoveForward;
				case ButtonRow.Types.MoveBackward:
					return _bindings.MoveBackward;
				case ButtonRow.Types.AimLeft:
					return _bindings.AimLeft;
				case ButtonRow.Types.AimRight:
					return _bindings.AimRight;
				case ButtonRow.Types.AimUp:
					return _bindings.AimUp;
				case ButtonRow.Types.AimDown:
					return _bindings.AimDown;
				case ButtonRow.Types.Crouch:
					return _bindings.Crouch;
				case ButtonRow.Types.Jump:
					return _bindings.Jump;
				case ButtonRow.Types.Fire:
					return _bindings.Fire;
				case ButtonRow.Types.ChangeView:
					return _bindings.ChangeView;
				default:
					return null;
			}
		}

		void SensitivityChanged(SensitivityRow.Types type, float value)
		{
			switch (type)
			{
				case SensitivityRow.Types.Horizontal:
					_bindings.SensitivityX = value;
					break;
				case SensitivityRow.Types.Vertical:
					_bindings.SensitivityY = value;
					break;
			}

			_bindings.Save();
		}

		public void Reset()
		{
			Bindings.Reset();
			Setup();
		}

		void Update()
		{
			if (_listening == null)
				return;

			if (_inputState.FindFirstDown(InputCode.KeyEscape) != null)
			{
				StopListening();
				return;
			}

			var code = InputCode.None;

			if (CheckButtons(ref code))
			{
				Commit(code);
				return;
			}

			foreach (var device in _inputState.Devices)
			{
				if (CheckMouse(device, ref code) || CheckSticks(device, ref code))
				{
					Commit(code);
					return;
				}
			}
		}

		bool CheckButtons(ref InputCode code)
		{
			IDevice device;
			IVirtualAxis axis;

			if (!_inputState.FindFirstUp(out device, out axis, InputUtils.ButtonAxes))
				return false;

			code = axis.Code;
			return true;
		}

		bool CheckAnalog(
			IDevice device, ref InputCode outCode, InputCode xCode, InputCode yCode,
			InputCode rightCode, InputCode leftCode, InputCode upCode, InputCode downCode,
			float threshold)
		{
			var xAxis = device[xCode];
			var yAxis = device[yCode];

			if (xAxis == null || yAxis == null)
				return false;

			var x = xAxis.Value;
			var y = yAxis.Value;
			var absX = Mathf.Abs(x);
			var absY = Mathf.Abs(y);

			if (absX < threshold || absY < threshold)
				return false;

			if (absY > absX)
				outCode = y > 0 ? upCode : downCode;
			else if (absX > absY)
				outCode = x > 0 ? rightCode : leftCode;

			return true;
		}

		bool CheckMouse(IDevice device, ref InputCode code)
		{
			return CheckAnalog(device, ref code,
				InputCode.MouseX, InputCode.MouseY,
				InputCode.MouseXRight, InputCode.MouseXLeft,
				InputCode.MouseYUp, InputCode.MouseYDown, 1f);
		}

		bool CheckSticks(IDevice device, ref InputCode code)
		{
			var threshold = 0.1f;

			if (CheckAnalog(device, ref code,
				InputCode.PadLeftStickX, InputCode.PadLeftStickY,
				InputCode.PadLeftStickRight, InputCode.PadLeftStickLeft,
				InputCode.PadLeftStickUp, InputCode.PadLeftStickDown, threshold))
				return true;

			if (CheckAnalog(device, ref code,
				InputCode.PadRightStickX, InputCode.PadRightStickY,
				InputCode.PadRightStickRight, InputCode.PadRightStickLeft,
				InputCode.PadRightStickUp, InputCode.PadRightStickDown, threshold))
				return true;

			return false;
		}

		void Commit(InputCode code)
		{
			if (code == InputCode.None)
				return;

			var list = GetBindings(_listening.Value);
			_bindings.Bind(list, code, _listeningSlot);
			StopListening();
		}

		void StartListening(ButtonRow.Types type, int slot)
		{
			_listening = type;
			_listeningSlot = slot;
			Instructions.gameObject.SetActive(true);

			_eventSystem.enabled = false;
			_inputState.Reset();
		}

		void StopListening()
		{
			if (_listening == null)
				return;

			UpdateAllButtonRows();
			_bindings.Save();

			_listening = null;
			Instructions.gameObject.SetActive(false);

			_inputState.Reset();
			_eventSystem.enabled = true;
		}
	}
}
