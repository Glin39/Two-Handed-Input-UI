using System;
using System.Text.RegularExpressions;
using UnityEngine;
using UnityEngine.UI;

// ReSharper disable UnassignedField.Global

namespace RavingBots.Bunnihilation
{
	public class ButtonRow : MonoBehaviour
	{
		public enum Types
		{
			MoveLeft,
			MoveRight,
			MoveForward,
			MoveBackward,
			AimLeft,
			AimRight,
			AimUp,
			AimDown,
			Crouch,
			Jump,
			Fire,
			ChangeView
		}

		public Text Label;
		public Button Slot1;
		[NonSerialized] public Text Slot1Label;
		public Button Slot2;
		[NonSerialized] public Text Slot2Label;
		public Button Slot3;
		[NonSerialized] public Text Slot3Label;
		public Types Type;
		[NonSerialized] public Text[] SlotLabels;

		void OnEnable()
		{
			Slot1Label = Slot1.GetComponentInChildren<Text>();
			Slot2Label = Slot2.GetComponentInChildren<Text>();
			Slot3Label = Slot3.GetComponentInChildren<Text>();
			var label = Regex.Replace(Type.ToString(), "([A-Z])", " $1", RegexOptions.CultureInvariant);
			Label.text = label.Trim();
			SlotLabels = new[]
			{
				Slot1Label,
				Slot2Label,
				Slot3Label
			};
		}

		public void Attach(Action<Types, int> onClick)
		{
			Slot1.onClick.AddListener(() => onClick(Type, 0));
			Slot2.onClick.AddListener(() => onClick(Type, 1));
			Slot3.onClick.AddListener(() => onClick(Type, 2));
		}

		void OnDisable()
		{
			Reset();
		}

		public void Reset()
		{
			Slot1.onClick.RemoveAllListeners();
			Slot2.onClick.RemoveAllListeners();
			Slot3.onClick.RemoveAllListeners();
		}
	}
}
