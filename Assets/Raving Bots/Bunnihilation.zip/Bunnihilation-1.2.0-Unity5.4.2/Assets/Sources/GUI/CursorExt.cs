﻿using UnityEngine;

namespace RavingBots.Bunnihilation
{
	public static class CursorExt
	{
		public static void Release()
		{
			Cursor.lockState = CursorLockMode.None;
			Cursor.visible = true;
		}

		public static void Lock()
		{
			Cursor.lockState = CursorLockMode.Locked;
			Cursor.visible = false;
		}
	}
}
