using System;
using UnityEngine;
using UnityEngine.UI;

// ReSharper disable UnassignedField.Global

namespace RavingBots.Bunnihilation

{
	public class SensitivityRow : MonoBehaviour
	{
		public enum Types
		{
			Horizontal,
			Vertical
		}

		public Text Label;
		public Slider Slider;
		public Text ValueLabel;
		public Types Type;

		void OnEnable()
		{
			Reset();
			UpdateLabel(Slider.value);
			Label.text = string.Format("{0} Sensitivity", Type);
		}

		void OnDisable()
		{
			Slider.onValueChanged.RemoveAllListeners();
		}

		public void Attach(Action<Types, float> callback)
		{
			Slider.onValueChanged.AddListener(v => callback(Type, v));
		}

		void UpdateLabel(float newValue)
		{
			ValueLabel.text = string.Format("{0:F0}%", newValue * 100);
		}

		public void Reset()
		{
			Slider.onValueChanged.RemoveAllListeners();
			Slider.onValueChanged.AddListener(UpdateLabel);
		}
	}
}
