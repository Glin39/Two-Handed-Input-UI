using System;
using System.Collections.Generic;
using System.Linq;
using RavingBots.MultiInput;
using UnityEngine;

// ReSharper disable UnassignedField.Global

namespace RavingBots.Bunnihilation
{
	public class AssignDevices : MonoBehaviour
	{
		public GameObject Panel;
		public GameObject RowPrefab;

		readonly List<DeviceRow> _rows = new List<DeviceRow>();
		int _current;
		InputState _inputState;
		MainMenu _mainMenu;
		GameInfo _gameInfo;

		void Awake()
		{
			_inputState = FindObjectOfType<InputState>();
			_gameInfo = GameInfo.Find();
			_mainMenu = GetComponent<MainMenu>();
		}

		void OnDisable()
		{
			Panel.SetActive(false);
		}

		void Update()
		{
			if (Input.GetKeyDown(KeyCode.Escape))
			{
				_mainMenu.ShowMain();
				return;
			}

			if (_rows.Count == 0)
				return;

			var player = _rows[_current].Player;
			IDevice device;
			InputCode code;

			if (!FindInput(out device, out code))
				return;

			Assign(device, code);

			if (player.Ready)
			{
				var next = _current + 1;

				if (next < _rows.Count)
					SetCurrent(next);
				else
					_gameInfo.Play();
			}
			else
				SetInstructions(true);
		}

		bool FindInput(out IDevice outDevice, out InputCode outCode)
		{
			var player = _rows[_current].Player;

			Func<IDevice, IVirtualAxis, bool> predicate = (device, axis) =>
			{
				if (IsAssigned(device))
					return false;
				if (player.HasKeyboard && !axis.Code.IsMouse())
					return false;
				if (player.HasMouse && !axis.Code.IsKeyboard())
					return false;

				return axis.IsUp;
			};

			IVirtualAxis outAxis;
			var result = _inputState.FindFirst(out outDevice, out outAxis, predicate, InputUtils.ButtonAxes);
			if (result)
			{
				outCode = outAxis.Code;
				return true;
			}

			outCode = InputCode.None;
			return false;
		}

		bool IsAssigned(IDevice device)
		{
			return _rows != null && _rows.Any(row => row.Player.Devices.Contains(device));
		}

		void Assign(IDevice device, InputCode code)
		{
			var row = _rows[_current];
			var player = row.Player;
			player.Assign(device, code);
			row.SetIcon(player.Devices.Count == 1 ? row.Icon2 : row.Icon1, code);
		}

		public void Setup()
		{
			foreach (Transform child in Panel.transform)
				Destroy(child.gameObject);

			_current = 0;
			_rows.Clear();
			Panel.SetActive(true);

			for (var idx = 0; idx < _gameInfo.PlayerCount; ++idx)
			{
				var obj = Instantiate(RowPrefab);
				var row = obj.GetComponent<DeviceRow>();
				row.name = row.Id.text = string.Format("Player {0}", idx + 1);
				row.Player = _gameInfo.Players[idx];
				row.transform.SetParent(Panel.transform);
				row.gameObject.SetActive(true);
				row.enabled = true;
				_rows.Add(row);
			}

			SetCurrent(0);
			_inputState.Reset();
		}

		void SetCurrent(int idx)
		{
			_rows[_current].Instructions.text = "";
			_current = idx;
			SetInstructions();
		}

		void SetInstructions(bool partial = false)
		{
			var row = _rows[_current];
			if (partial)
			{
				row.Instructions.text = row.Player.HasKeyboard
					? "Please select a mouse by pressing any button on it."
					: "Please select a keyboard by pressing any key on it.";
			}
			else
				row.Instructions.text = "Please select your device (keyboard, mouse, or pad) by pressing any button.";
		}
	}
}
