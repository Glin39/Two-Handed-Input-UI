using UnityEngine;
using UnityEngine.UI;

namespace RavingBots.Bunnihilation
{
	[RequireComponent(typeof(Camera))]
	public class HUD : MonoBehaviour
	{
		public Image HealthBar;
		public Image ScoreBg;
		public Text ScoreText;
		public Image AmmoBg;
		public Text AmmoText;
		public float AmmoWidth = 10f;

		Color _color;
		public Color Color
		{
			get { return _color; }
			set
			{
				if (_color == value)
					return;

				_color = value;

				UpdateColor(_color);
            }
		}

		int _score;
		public int Score
		{
			get { return _score; }
			set
			{
				if (_score == value)
					return;

				_score = value;

				UpdateScore(_score);
			}
		}

		float _health;
		public float Health
		{
			get { return _health; }
			set
			{
				if (_health == value)
					return;

				_health = value;

				UpdateHealth(_health);
			}
		}

		int _ammo;
		public int Ammo
		{
			get { return _ammo; }
			set
			{
				if (_ammo == value)
					return;

				_ammo = value;

				UpdateAmmo(_ammo);
			}
		}

		public Camera Camera { get; private set; }

		PlayerInfo _playerInfo;

		void Awake()
		{
			Camera = GetComponent<Camera>();

			_playerInfo = GetComponentInParent<PlayerInfo>();

			UpdateColor(Color);
			UpdateScore(Score);
			UpdateHealth(Health);
			UpdateAmmo(Ammo);
		}

		void UpdateColor(Color color)
		{
			HealthBar.color = color;
			ScoreBg.color = color;
			AmmoBg.color = color;
        }

		void UpdateScore(int score)
		{
			ScoreText.text = score >= 0 ? score.ToString() : score + " ";
		}

		void UpdateAmmo(int ammo)
		{
			AmmoText.text = ammo.ToString();
			var size = AmmoBg.rectTransform.sizeDelta;
			size.x = AmmoWidth * ammo;
			AmmoBg.rectTransform.sizeDelta = size;
        }

		void UpdateHealth(float health)
		{
			var anchor = HealthBar.rectTransform.anchorMax;
			anchor.x = health;
			HealthBar.rectTransform.anchorMax = anchor;
		}

		void LateUpdate()
		{
			var pawn = _playerInfo.PawnController.Pawn;
			if (pawn)
			{
				Health = pawn.Health / pawn.InitialHealth;
				if (pawn.Weapon)
					Ammo = Mathf.FloorToInt(pawn.Weapon.Ammo);
			}
		}
	}
}
