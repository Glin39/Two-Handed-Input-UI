using System;
using RavingBots.MultiInput;
using UnityEngine;
using UnityEngine.UI;

// ReSharper disable UnassignedField.Global

namespace RavingBots.Bunnihilation
{
	public class DeviceRow : MonoBehaviour
	{
		public Text Id;
		public Text Instructions;
		public Image Icon1;
		public Image Icon2;
		public Sprite KeyboardSprite;
		public Sprite MouseSprite;
		public Sprite PadSprite;
		[NonSerialized] public PlayerInfo Player;

		void Awake()
		{
			Id.text = "";
			Instructions.text = "";
			Icon1.gameObject.SetActive(false);
			Icon2.gameObject.SetActive(false);
		}

		public void SetIcon(Image image, InputCode code)
		{
			if (code.IsKeyboard())
				image.sprite = KeyboardSprite;
			else if (code.IsMouse())
				image.sprite = MouseSprite;
			else if (code.IsGamepad())
				image.sprite = PadSprite;

			image.gameObject.SetActive(true);
		}
	}
}
