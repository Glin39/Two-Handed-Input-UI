﻿using UnityEngine;
using System.Collections.Generic;

namespace RavingBots.Bunnihilation
{
	public class ObjectPool<T> where T : MonoBehaviour, IPooledObject<T>
	{
		const string RootName = "Pool Root";

		readonly T _prefab;
		readonly Queue<T> _queue = new Queue<T>();

		Transform _poolRoot;
		Transform PoolRoot
		{
			get
			{
				if (_poolRoot)
					return _poolRoot;

				var root = GameObject.Find(RootName);
				_poolRoot = root ? root.transform : new GameObject(RootName).transform;

				return _poolRoot;
			}
		}

		Transform _parent;
		Transform Parent
		{
			get
			{
				if (_parent)
					return _parent;

				_parent = new GameObject(typeof(T).Name + " Pool").transform;
				_parent.parent = PoolRoot;
				_parent.gameObject.SetActive(false);

				return _parent;
			}
		}

		public ObjectPool(T prefab, int precache = 0)
		{
			_prefab = prefab;

			var precached = new List<T>();
			for (var i = 0; i < precache; i++)
				precached.Add(TakeInstance());

			foreach (var obj in precached)
				RevokeInstance(obj);
		}

		public T TakeInstance()
		{
			if (_queue.Count > 0)
			{
				var result = _queue.Dequeue();
                result.transform.parent = null;
				result.Queued = false;
				return result;
			}
			else
			{
				var result = Object.Instantiate(_prefab.gameObject).GetComponent<T>();
				result.gameObject.SetActive(false);
				result.Pool = this;
				return result;
			}
		}

		public T TakeInstance(Vector3 position, bool activate = false)
		{
			var result = TakeInstance();
			result.transform.position = position;

			if (activate)
				result.gameObject.SetActive(true);

			return result;
		}

		public void RevokeInstance(T obj)
		{
			if (obj.gameObject.activeSelf)
				obj.gameObject.SetActive(false);

			obj.transform.parent = Parent;
			_queue.Enqueue(obj);
			obj.Queued = true;
		}
	}
}
