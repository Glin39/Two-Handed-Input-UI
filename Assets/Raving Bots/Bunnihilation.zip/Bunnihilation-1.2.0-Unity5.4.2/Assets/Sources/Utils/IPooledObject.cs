using UnityEngine;

namespace RavingBots.Bunnihilation
{
	public interface IPooledObject<T> where T : MonoBehaviour, IPooledObject<T>
	{
		bool Queued { get; set; }
		ObjectPool<T> Pool { get; set; }
	}
}
