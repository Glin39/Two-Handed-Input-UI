using UnityEngine;
using System.Linq;

namespace RavingBots.Bunnihilation
{
	public class RenderColor
	{
		Color _color;
		public Color Color
		{
			get { return _color; }
			set
			{
				if (_color == value)
					return;

				_color = value;

				SetColor(_color);
            }
		}

		bool _visible;
		public bool Visible
		{
			get { return _visible; }
			set
			{
				if (_visible == value)
					return;

				_visible = value;

				SetVisible(_visible);
			}
		}

		MeshRenderer[] _renderers;
		Color _initialColor;
		bool _initialVisiblity;

		public void Init(MonoBehaviour obj)
		{
			_renderers = obj.GetComponentsInChildren<MeshRenderer>()
				.Where(mr => mr.shadowCastingMode != UnityEngine.Rendering.ShadowCastingMode.ShadowsOnly).ToArray();

			var r = _renderers[0];
			_initialColor = _color = r.material.color;
			_initialVisiblity = _visible = r.enabled;

			SetColor(Color);
			SetVisible(Visible);
        }

		void SetColor(Color color)
		{
			foreach (var r in _renderers)
				r.material.color = color;
		}

		void SetVisible(bool state)
		{
			foreach (var r in _renderers)
				r.enabled = state;
		}

		public void Reset()
		{
			Color = _initialColor;
			Visible = _initialVisiblity;
		}
	}
}
