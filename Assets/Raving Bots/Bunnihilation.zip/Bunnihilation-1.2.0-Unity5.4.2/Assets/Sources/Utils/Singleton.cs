using UnityEngine;

namespace RavingBots.Bunnihilation
{
	public class Singleton<T> : MonoBehaviour where T : MonoBehaviour
	{
		public static T Create()
		{
			return new GameObject(typeof(T).Name, typeof(T)).GetComponent<T>();
		}

		public static T Find()
		{
			var objects = FindObjectsOfType<T>();
			if (objects.Length > 1)
				Debug.LogWarning("Please make sure there is only one " + typeof(T).Name + " in the scene.");

			return objects.Length > 0 ? objects[0] : null;
		}
	}
}
